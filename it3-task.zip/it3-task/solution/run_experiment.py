"""
IT³ MNIST Classification Experiment — GROUND TRUTH SOLUTION
"""

import json
import os
import random
from copy import deepcopy

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

SEED   = 42
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)


class ZigZag(nn.Module):
    def __init__(self, in_features: int = 784, out_features: int = 10,
                 h1: int = 256, h2: int = 128) -> None:
        super().__init__()
        self.out_features = out_features
        self.fc1 = nn.Linear(in_features + out_features, h1)
        self.fc2 = nn.Linear(h1, h2)
        self.fc3 = nn.Linear(h2, out_features)
        self.act = nn.ReLU()

    def forward(self, x: torch.Tensor, y: torch.Tensor = None) -> torch.Tensor:
        x_flat = x.view(x.shape[0], -1)
        if y is None:
            y = torch.zeros(x_flat.shape[0], self.out_features, device=x_flat.device)
        inp = torch.cat([x_flat, y], dim=1)
        return self.fc3(self.act(self.fc2(self.act(self.fc1(inp)))))


def get_mnist_loaders(data_root: str = "/workspace/data",
                      train_batch: int = 256,
                      test_batch: int = 256,
                      seed: int = SEED):
    transform    = transforms.Compose([transforms.ToTensor()])
    train_ds     = datasets.MNIST(data_root, train=True,  download=False, transform=transform)
    test_ds      = datasets.MNIST(data_root, train=False, download=False, transform=transform)
    g = torch.Generator()
    g.manual_seed(seed)
    train_loader = DataLoader(train_ds, batch_size=train_batch, shuffle=True,  generator=g)
    test_loader  = DataLoader(test_ds,  batch_size=test_batch,  shuffle=False)
    return train_loader, test_loader


def train(model: ZigZag, train_loader, epochs: int = 50,
          lr: float = 1e-3, aug_sigma: float = 0.0,
          y_noise_std: float = 0.3, seed: int = SEED) -> ZigZag:
    """
    Train ZigZag with noisy label conditioning.

    The y_noise_std parameter adds Gaussian noise to the one-hot label signal
    before passing it to the label-conditioned path.  This prevents the model
    from learning the trivial shortcut f(x, y) ≈ y (echo the label back),
    forcing it to fuse both x and the noisy hint to predict the true class.
    The y=0 path is unaffected.
    """
    set_seed(seed)
    aug_rng = torch.Generator()
    aug_rng.manual_seed(seed + 1)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    ce        = nn.CrossEntropyLoss()
    model.to(DEVICE)
    for epoch in range(epochs):
        model.train()
        for x, y in train_loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            if aug_sigma > 0 and torch.rand(1, generator=aug_rng).item() < 0.5:
                x = (x + torch.randn_like(x) * aug_sigma).clamp(0, 1)
            y_oh = F.one_hot(y, 10).float()
            # Noisy label: clamp-then-normalise keeps it on the probability simplex
            y_noisy = (y_oh + torch.randn_like(y_oh) * y_noise_std).clamp(0)
            y_noisy = y_noisy / y_noisy.sum(dim=1, keepdim=True).clamp(min=1e-8)
            logits0 = model(x)
            logits1 = model(x, y_noisy)
            loss    = ce(logits0, y) + ce(logits1, y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print(f"  Epoch {epoch + 1}/{epochs} done.")
    model.eval()
    return model


def eval_baseline(model: ZigZag, test_loader,
                  sigma: float = 0.5, seed: int = 1) -> float:
    torch.manual_seed(seed)
    model.eval()
    correct = 0
    total   = 0
    with torch.no_grad():
        for x, y in test_loader:
            x_noisy = (x + torch.randn_like(x) * sigma).clamp(0, 1)
            logits  = model(x_noisy.to(DEVICE))
            preds   = logits.argmax(1).cpu()
            correct += (preds == y).sum().item()
            total   += len(y)
    return correct / total


def run_it3_ttt(model: ZigZag, test_loader,
                sigma: float = 0.5, n_steps: int = 100,
                lr: float = 1e-3, seed: int = 1) -> float:
    """Ground-truth IT³ TTT implementation for MNIST."""
    torch.manual_seed(seed)

    # Create both copies from model before disabling grad on frozen
    f_frozen = deepcopy(model)
    f_ttt    = deepcopy(model)
    f_frozen.eval()
    for p in f_frozen.parameters():
        p.requires_grad_(False)
    f_ttt.to(DEVICE)

    correct = 0
    total   = 0

    for x, y in test_loader:
        x_noisy = (x + torch.randn_like(x) * sigma).clamp(0, 1)
        xb      = x_noisy.to(DEVICE)

        # Reset f_ttt to frozen weights at the start of every batch
        f_ttt.load_state_dict(f_frozen.state_dict())
        f_ttt.train()
        optimizer = optim.Adam(f_ttt.parameters(), lr=lr)

        # IT³ optimization: minimise idempotence error (no labels used)
        # Stop-gradient on y1 inside f_frozen avoids near-zero gradients from
        # the shortcut f(x,y)≈y and makes the EM-style update converge reliably.
        for _ in range(n_steps):
            y1 = torch.softmax(f_ttt(xb), dim=1)        # f_ttt(x, 0) as probs
            with torch.no_grad():
                y2 = torch.softmax(f_frozen(xb, y1), dim=1)  # F(x, y1) — frozen, no grad
            loss = (y1 - y2).abs().mean()
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # Final prediction: frozen model F(x, f_ttt(x, 0))
        f_ttt.eval()
        with torch.no_grad():
            y1      = torch.softmax(f_ttt(xb), dim=1)
            logits2 = f_frozen(xb, y1)

        preds   = logits2.argmax(1).cpu()
        correct += (preds == y).sum().item()
        total   += len(y)

    return correct / total


if __name__ == "__main__":
    RESULTS_PATH = "/workspace/results.json"

    set_seed(SEED)
    print(f"Device: {DEVICE}")

    print("Loading MNIST...")
    train_loader, test_loader = get_mnist_loaders("/workspace/data", seed=SEED)

    SIGMA = 0.3

    print("Training ZigZag model (50 epochs, clean data only, seed=42)...")
    model = ZigZag(in_features=784, out_features=10).to(DEVICE)
    model = train(model, train_loader, epochs=50, lr=1e-3, aug_sigma=0.0, seed=SEED)
    print("Training complete.")

    # Sanity-check: a properly trained model should exceed 85% on clean data
    clean_acc = eval_baseline(model, test_loader, sigma=0.0, seed=1)
    print(f"Clean accuracy (sigma=0.0): {clean_acc:.4f}")
    if clean_acc < 0.85:
        print(f"WARNING: clean accuracy {clean_acc:.4f} < 0.85 — model may not have converged")

    baseline_acc = eval_baseline(model, test_loader, sigma=SIGMA, seed=1)
    print(f"Baseline accuracy (sigma={SIGMA}, no TTT): {baseline_acc:.4f}")

    it3_acc = run_it3_ttt(model, test_loader, sigma=SIGMA, n_steps=100, lr=1e-3, seed=1)
    print(f"IT³ accuracy      (sigma={SIGMA}, steps=100): {it3_acc:.4f}")

    improves   = bool(it3_acc > baseline_acc)
    conclusion = (
        f"IT³ achieves accuracy={it3_acc:.4f} vs baseline accuracy={baseline_acc:.4f} "
        f"on Gaussian-corrupted MNIST (sigma={SIGMA:.1f}). "
        + ("IT³ improves classification accuracy over the non-adapted baseline."
           if improves
           else "IT³ did not improve accuracy in this run.")
    )
    results = {
        "baseline_acc": round(baseline_acc, 6),
        "it3_acc":      round(it3_acc,      6),
        "it3_improves_over_baseline": improves,
        "conclusion":   conclusion,
    }
    os.makedirs(os.path.dirname(RESULTS_PATH), exist_ok=True)
    with open(RESULTS_PATH, "w") as f:
        json.dump(results, f, indent=2)
    print(json.dumps(results, indent=2))
