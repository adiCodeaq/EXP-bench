#!/bin/bash
# Ground-truth solution for the IT³ tabular Harbor task.
# Replaces the stubbed run_experiment.py with the complete implementation
# and runs the experiment.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== Copying ground-truth run_experiment.py ==="
cp "${SCRIPT_DIR}/run_experiment.py" /workspace/run_experiment.py

echo "=== Running IT³ experiment ==="
python /workspace/run_experiment.py

echo "=== solve.sh complete. Results at /workspace/results.json ==="
