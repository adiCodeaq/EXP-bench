# Research Task: IT³ — Idempotent Test-Time Training on MNIST

## Research Question

Does IT³ (Idempotent Test-Time Training) improve classification accuracy compared
to a non-adapted baseline when classifying MNIST digits from Gaussian-noisy inputs
(sigma=0.3)?

## Background

**IT³** is a test-time training method that requires no domain-specific auxiliary task.
Instead, it exploits *idempotence*: a model trained so that `f(x, f(x,0)) ≈ f(x,0)`
can be adapted at test time by minimizing the *idempotence error* for each incoming
test batch.

**Training phase**: The model `f_θ` (a ZigZag network) takes both the input `x` and
a label signal `y` (or a neutral zero vector). It is trained to predict correctly both
with and without access to the label, using a **noisy label** for the conditioned path
to prevent the trivial shortcut of echoing the label signal:

```
L_train = CE(f(x, 0), y) + CE(f(x, y_noisy), y)
```

where `y_noisy` is the one-hot label perturbed with Gaussian noise (std=0.3) and
projected back to the probability simplex. This noise forces the model to fuse both
the image features **and** the approximate label hint to predict correctly — making
it genuinely useful for IT³ at test time.

**Test-time adaptation (IT³)**: Given a corrupted test batch `x̃`, the model briefly
optimizes a copy of itself to minimize the IT³ idempotence loss:

```
L_IT3 = ||softmax(f_θ(x̃, 0)) − softmax(F(x̃, softmax(f_θ(x̃, 0))))||₁
```

where `F` is the **frozen** reference model (weights fixed after training) and `f_θ`
is the copy being updated. After `n_steps` gradient steps, the prediction is
`F(x̃, softmax(f_θ(x̃, 0)))`.

The key insight: when the current batch is out-of-distribution (corrupted), the
idempotence error is large. Minimizing it pulls the model toward its idempotent
fixed point — without needing any labels.

## Repository and File Structure

```
/workspace/
├── data/                  # MNIST dataset (pre-downloaded)
└── run_experiment.py      # Main experiment script — EDIT THIS FILE
```

The `run_experiment.py` file contains:
- `ZigZag`: the IT³ model architecture (fully implemented)
- `get_mnist_loaders()`: data loading (fully implemented)
- `train()`: ZigZag training loop with noisy-label conditioning (fully implemented)
- `eval_baseline()`: evaluates the non-adapted model (fully implemented)
- `run_it3_ttt()`: **YOU MUST IMPLEMENT THIS FUNCTION**

## Step-by-Step Instructions

### Step 1: Understand the ZigZag Model

Open `/workspace/run_experiment.py` and read the `ZigZag` class. Note:
- `forward(x, y=None)` accepts an optional label signal `y`
- When `y=None`, it uses a zero vector as the label input (neutral signal)
- During training, called as `f(x, 0)` and `f(x, y_noisy)` — the second path is
  trained with a noisy label so the model learns to **fuse image and label signals**
  rather than just echoing the label

### Step 2: Implement `run_it3_ttt()`

Find the `run_it3_ttt()` stub and implement it.

The function signature is:
```python
def run_it3_ttt(model, test_loader, sigma=0.3, n_steps=100, lr=1e-3, seed=1) -> float:
```

Your implementation must:

1. **Create a frozen copy**: `f_frozen = deepcopy(model)`, set `f_frozen.eval()`,
   then disable gradients on all parameters.

2. **Create an adaptable copy**: `f_ttt = deepcopy(model)` (fresh copy, NOT from f_frozen).

3. **For each batch `(x, y)` from `test_loader`**:
   a. Apply Gaussian noise: `x_noisy = (x + torch.randn_like(x) * sigma).clamp(0, 1)`.
      Move to DEVICE.
   b. **Reset** `f_ttt` to frozen weights: `f_ttt.load_state_dict(f_frozen.state_dict())`.
   c. Set `f_ttt.train()`, create `optimizer = optim.Adam(f_ttt.parameters(), lr=lr)`.
   d. Run `n_steps` gradient steps minimizing the IT³ idempotence loss.
      **Important**: use `torch.no_grad()` when computing `y2` to apply the
      stop-gradient (EM-style) update — this prevents near-zero gradients from
      the shortcut and lets the iteration reliably converge to the fixed point:
      ```python
      y1 = torch.softmax(f_ttt(xb), dim=1)          # f_ttt(x, 0) as probs
      with torch.no_grad():
          y2 = torch.softmax(f_frozen(xb, y1), dim=1)  # F(x, y1) — no grad through here
      loss = (y1 - y2).abs().mean()
      optimizer.zero_grad(); loss.backward(); optimizer.step()
      ```
   e. After optimization, compute the final prediction:
      ```python
      f_ttt.eval()
      with torch.no_grad():
          y1      = torch.softmax(f_ttt(xb), dim=1)
          logits2 = f_frozen(xb, y1)   # frozen model with adapted signal
      preds = logits2.argmax(1)
      ```
   f. Accumulate correct predictions and total count.

4. **Return** overall accuracy: `correct / total` (float in [0, 1]).

**Important**: The IT³ loss does NOT use ground-truth labels. It is self-supervised.
Reset `f_ttt` at the start of every batch.

### Step 3: Run the Experiment

```bash
cd /workspace
python run_experiment.py
```

The script will:
1. Load MNIST from `/workspace/data`
2. Train a ZigZag model for 50 epochs with noisy-label conditioning (seed=42)
3. Evaluate clean accuracy as a sanity check (should be >85%)
4. Evaluate the non-adapted baseline with Gaussian noise sigma=0.3
5. Run IT³ TTT (n_steps=100, lr=1e-3)
6. Save results to `/workspace/results.json`

### Step 4: Check Results

The output file `/workspace/results.json` should look like:
```json
{
  "baseline_acc": 0.7392,
  "it3_acc": 0.7403,
  "it3_improves_over_baseline": true,
  "conclusion": "IT³ achieves accuracy=0.7403 vs baseline accuracy=0.7392 on Gaussian-corrupted MNIST (sigma=0.3). IT³ improves classification accuracy over the non-adapted baseline."
}
```

The key finding: IT³ adapts per-batch to the specific noise realization, consistently
finding the idempotent fixed point and achieving slightly higher accuracy than the
non-adapted baseline.

## Key Implementation Details

- `model.forward(x, y=None)`: when `y=None`, uses a zero vector as the label input.
- Create BOTH `f_frozen` and `f_ttt` from the original `model` (not f_frozen from f_ttt),
  then disable grad on f_frozen.
- The **frozen** reference model `f_frozen` must NOT have its weights updated.
- Reset `f_ttt` to frozen weights at the start of **every** batch (per-batch reset).
- Use `torch.softmax(..., dim=1)` to convert logits to probabilities before feeding
  as the label signal to the frozen model.
- Move `xb` to DEVICE before passing to either model.
- **Use `torch.no_grad()` when computing y2** — this is the stop-gradient that
  makes the EM-style update converge to the correct fixed point.
- The final prediction uses `logits2 = f_frozen(xb, y1)` — the frozen model's output.

## Expected Outcome

IT³ exploits the model's idempotent structure to find a self-consistent prediction
under Gaussian noise corruption:
- **Baseline** (no adaptation): ~73-74% accuracy on sigma=0.3 corrupted MNIST
- **IT³** (100 adaptation steps): slightly higher accuracy, demonstrating the
  test-time adaptation benefit

The IT³ accuracy should be strictly greater than the baseline accuracy.
