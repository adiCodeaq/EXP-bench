"""
IT³ MNIST Classification Experiment
=====================================
Research question: Does IT³ (Idempotent Test-Time Training) improve accuracy
compared to a non-adapted baseline when classifying MNIST digits corrupted by
Gaussian noise (sigma=0.3)?

This file contains:
  - ZigZag: the IT³ model architecture (fully implemented)
  - get_mnist_loaders(): data loading (fully implemented)
  - train(): ZigZag dual-path training with noisy-label conditioning (fully implemented)
  - eval_baseline(): non-adapted evaluation (fully implemented)
  - run_it3_ttt(): IT³ test-time training  <<< YOU MUST IMPLEMENT THIS >>>

Run:  python run_experiment.py
Output: /workspace/results.json
"""

import json
import os
import random
from copy import deepcopy

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

# ── Globals ──────────────────────────────────────────────────────────────────
SEED   = 42
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)


# ── Model ─────────────────────────────────────────────────────────────────────
class ZigZag(nn.Module):
    """
    ZigZag MLP for MNIST classification.

    Takes a flattened image x (784-dim) and an optional label signal y (10-dim).
    When y=None, uses a zero vector as the neutral label signal.
    Trained with both paths: f(x, 0) and f(x, y_noisy) → same true label.
    """

    def __init__(self, in_features: int = 784, out_features: int = 10,
                 h1: int = 256, h2: int = 128) -> None:
        super().__init__()
        self.out_features = out_features
        self.fc1 = nn.Linear(in_features + out_features, h1)
        self.fc2 = nn.Linear(h1, h2)
        self.fc3 = nn.Linear(h2, out_features)
        self.act = nn.ReLU()

    def forward(self, x: torch.Tensor, y: torch.Tensor = None) -> torch.Tensor:
        x_flat = x.view(x.shape[0], -1)
        if y is None:
            y = torch.zeros(x_flat.shape[0], self.out_features, device=x_flat.device)
        inp = torch.cat([x_flat, y], dim=1)
        return self.fc3(self.act(self.fc2(self.act(self.fc1(inp)))))


# ── Data ──────────────────────────────────────────────────────────────────────
def get_mnist_loaders(data_root: str = "/workspace/data",
                      train_batch: int = 256,
                      test_batch: int = 256,
                      seed: int = SEED):
    """Return (train_loader, test_loader) for MNIST."""
    transform = transforms.Compose([transforms.ToTensor()])
    train_ds  = datasets.MNIST(data_root, train=True,  download=False, transform=transform)
    test_ds   = datasets.MNIST(data_root, train=False, download=False, transform=transform)
    g = torch.Generator()
    g.manual_seed(seed)
    train_loader = DataLoader(train_ds, batch_size=train_batch, shuffle=True,  generator=g)
    test_loader  = DataLoader(test_ds,  batch_size=test_batch,  shuffle=False)
    return train_loader, test_loader


# ── Training ──────────────────────────────────────────────────────────────────
def train(model: ZigZag, train_loader, epochs: int = 50,
          lr: float = 1e-3, aug_sigma: float = 0.0,
          y_noise_std: float = 0.3, seed: int = SEED) -> ZigZag:
    """
    Train ZigZag with noisy-label conditioning.

    Two training paths per batch:
      1. f(x, 0)       → y    neutral path, trains pure image classification
      2. f(x, y_noisy) → y    label path, y_noisy = one-hot + N(0, y_noise_std²)
                               projected onto the simplex

    The noisy label prevents the trivial shortcut f(x, y) ≈ y (echoing the label
    back without using the image).  The model must fuse image features and the
    approximate label hint — exactly the structure IT³ exploits at test time.
    """
    set_seed(seed)
    aug_rng = torch.Generator()
    aug_rng.manual_seed(seed + 1)
    optimizer = optim.Adam(model.parameters(), lr=lr)
    ce        = nn.CrossEntropyLoss()
    model.to(DEVICE)
    for epoch in range(epochs):
        model.train()
        for x, y in train_loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            if aug_sigma > 0 and torch.rand(1, generator=aug_rng).item() < 0.5:
                x = (x + torch.randn_like(x) * aug_sigma).clamp(0, 1)
            y_oh = F.one_hot(y, 10).float()
            # Noisy label: clamp then re-normalise to keep on probability simplex
            y_noisy = (y_oh + torch.randn_like(y_oh) * y_noise_std).clamp(0)
            y_noisy = y_noisy / y_noisy.sum(dim=1, keepdim=True).clamp(min=1e-8)
            logits0 = model(x)           # f(x, 0) — neutral signal path
            logits1 = model(x, y_noisy)  # f(x, y_noisy) — noisy-label path
            loss    = ce(logits0, y) + ce(logits1, y)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        print(f"  Epoch {epoch + 1}/{epochs} done.")
    model.eval()
    return model


# ── Baseline evaluation ───────────────────────────────────────────────────────
def eval_baseline(model: ZigZag, test_loader,
                  sigma: float = 0.3, seed: int = 1) -> float:
    """
    Evaluate non-adapted model on Gaussian-noisy MNIST inputs.
    Returns classification accuracy (float in [0, 1]).
    """
    torch.manual_seed(seed)
    model.eval()
    correct = 0
    total   = 0
    with torch.no_grad():
        for x, y in test_loader:
            x_noisy = (x + torch.randn_like(x) * sigma).clamp(0, 1)
            logits  = model(x_noisy.to(DEVICE))
            preds   = logits.argmax(1).cpu()
            correct += (preds == y).sum().item()
            total   += len(y)
    return correct / total


# ── IT³ Test-Time Training ────────────────────────────────────────────────────
def run_it3_ttt(model: ZigZag, test_loader,
                sigma: float = 0.3, n_steps: int = 100,
                lr: float = 1e-3, seed: int = 1) -> float:
    """
    Implement IT³ Test-Time Training for MNIST classification.

    For each mini-batch of corrupted test inputs:
      1. Create a frozen reference F = deepcopy(model), eval mode, no gradients.
         Create an adaptable copy f_ttt = deepcopy(model) (separate copy, not from F).
      2. Reset f_ttt to frozen weights at the start of every batch.
      3. Optimize f_ttt for n_steps to minimise the IT³ idempotence loss.

         IMPORTANT — use stop-gradient (torch.no_grad) on the frozen model call:
             y1 = softmax(f_ttt(x, 0))                   # adapted probs
             with torch.no_grad():
                 y2 = softmax(F(x, y1))                  # frozen target — NO GRADIENT
             loss = (y1 - y2).abs().mean()

         Without the stop-gradient, the gradient through y1 as input to the frozen
         model nearly cancels out (because F(x,y)≈y learned during training), leaving
         a near-zero net gradient.  With it, each step is a clean EM update: train
         f_ttt to output the frozen model's improved prediction F(x, y1_current).

      4. Final prediction:
             f_ttt.eval()
             with torch.no_grad():
                 y1      = softmax(f_ttt(xb))
                 logits2 = F(xb, y1)
             preds = logits2.argmax(1)
      5. Accumulate correct predictions.

    Returns overall accuracy (float in [0, 1]).

    IMPORTANT NOTES:
    - The IT³ loss does NOT use ground-truth labels (self-supervised).
    - Create both f_frozen and f_ttt from model (NOT f_ttt from f_frozen).
    - Reset f_ttt to frozen weights at the START of every batch.
    - The frozen model is `model`; do NOT update its weights.
    - Apply Gaussian noise: x_noisy = (x + randn_like(x) * sigma).clamp(0, 1).
    - Move x_noisy to DEVICE before passing to either model.
    - Use torch.softmax(..., dim=1) to convert logits → probs for the label signal.
    - Use torch.no_grad() when computing y2 = F(xb, y1) inside the TTT loop.

    Args:
        model      : Trained ZigZag model — serves as the frozen reference F.
        test_loader: DataLoader over the clean test set.
        sigma      : Standard deviation of Gaussian noise (OOD corruption).
        n_steps    : Gradient steps per batch.
        lr         : Adam learning rate for TTT.
        seed       : Random seed for noise generation.

    Returns:
        float: Classification accuracy of IT³ predictions over the full test set.
    """
    # ── TODO: implement IT³ TTT ──────────────────────────────────────────────
    raise NotImplementedError(
        "Implement run_it3_ttt().\n"
        "See the docstring above and instruction.md for the algorithm."
    )


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    RESULTS_PATH = "/workspace/results.json"
    SIGMA        = 0.3

    set_seed(SEED)
    print(f"Device: {DEVICE}")

    # 1. Load MNIST
    print("Loading MNIST...")
    train_loader, test_loader = get_mnist_loaders("/workspace/data", seed=SEED)

    # 2. Train ZigZag (50 epochs, noisy-label conditioning, clean images)
    print("Training ZigZag model (50 epochs, y_noise_std=0.3, seed=42)...")
    model = ZigZag(in_features=784, out_features=10).to(DEVICE)
    model = train(model, train_loader, epochs=50, lr=1e-3, aug_sigma=0.0,
                  y_noise_std=0.3, seed=SEED)
    print("Training complete.")

    # Sanity-check on clean data
    clean_acc = eval_baseline(model, test_loader, sigma=0.0, seed=1)
    print(f"Clean accuracy (sigma=0.0): {clean_acc:.4f}")
    if clean_acc < 0.85:
        print(f"WARNING: clean accuracy {clean_acc:.4f} < 0.85 — model may not have converged")

    # 3. Baseline evaluation (Gaussian noise sigma=0.3)
    baseline_acc = eval_baseline(model, test_loader, sigma=SIGMA, seed=1)
    print(f"Baseline accuracy (sigma={SIGMA}, no TTT): {baseline_acc:.4f}")

    # 4. IT³ TTT (sigma=0.3, n_steps=100, lr=1e-3)
    it3_acc = run_it3_ttt(model, test_loader, sigma=SIGMA, n_steps=100, lr=1e-3, seed=1)
    print(f"IT³ accuracy     (sigma={SIGMA}, steps=100): {it3_acc:.4f}")

    # 5. Save results
    improves   = bool(it3_acc > baseline_acc)
    conclusion = (
        f"IT³ achieves accuracy={it3_acc:.4f} vs baseline accuracy={baseline_acc:.4f} "
        f"on Gaussian-corrupted MNIST (sigma={SIGMA:.1f}). "
        + ("IT³ improves classification accuracy over the non-adapted baseline."
           if improves
           else "IT³ did not improve accuracy in this run.")
    )
    results = {
        "baseline_acc": round(baseline_acc, 6),
        "it3_acc":      round(it3_acc,      6),
        "it3_improves_over_baseline": improves,
        "conclusion":   conclusion,
    }
    os.makedirs(os.path.dirname(RESULTS_PATH), exist_ok=True)
    with open(RESULTS_PATH, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to {RESULTS_PATH}")
    print(json.dumps(results, indent=2))
