#!/usr/bin/env python3
"""
grade.py — Grader for the IT³ MNIST Harbor task.

Evaluates four dimensions:
  D  Design correctness     — correct experimental setup
  I  Implementation         — correct IT³ TTT implementation
  E  Executability          — experiment ran and produced valid outputs
  C  Conclusion correctness — IT³ outperforms non-adapted baseline

Usage:
  python /tests/grade.py --results /workspace/results.json \
                         --impl    /workspace/run_experiment.py
"""

import argparse
import json
import os
import sys

# ── Rubric weights ────────────────────────────────────────────────────────────
RUBRIC = {
    "D": 0.25,
    "I": 0.35,
    "E": 0.20,
    "C": 0.20,
}

# Reasonable accuracy range for MNIST with Gaussian noise sigma=0.5
ACC_MIN_REASONABLE = 0.30
ACC_MAX_REASONABLE = 0.99


def load_results(path):
    if not os.path.isfile(path):
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def load_impl(path):
    if not os.path.isfile(path):
        return None
    with open(path) as f:
        return f.read()


# ── D: Design ─────────────────────────────────────────────────────────────────
def grade_design(results, impl_src):
    """
    D1 (50%): results.json contains both baseline_acc and it3_acc.
    D2 (50%): implementation code shows IT³ structure — frozen model,
              load_state_dict reset per batch, frozen model called with y1.
    """
    score = 0.0
    notes = []

    # D1
    if results is not None:
        has_b = ("baseline_acc" in results and
                 isinstance(results["baseline_acc"], (int, float)))
        has_i = ("it3_acc" in results and
                 isinstance(results["it3_acc"], (int, float)))
        if has_b and has_i:
            score += 0.50
            notes.append("D1 PASS: results.json has baseline_acc and it3_acc.")
        else:
            missing = []
            if not has_b: missing.append("baseline_acc")
            if not has_i: missing.append("it3_acc")
            notes.append(f"D1 FAIL: results.json missing {', '.join(missing)}.")
    else:
        notes.append("D1 FAIL: results.json not found or invalid.")

    # D2
    if impl_src is not None:
        code = "\n".join(
            ln for ln in impl_src.splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        )
        has_deepcopy    = "deepcopy" in code
        has_reset       = "load_state_dict" in code
        has_frozen_call = any(s in code for s in
                              ["f_frozen(xb", "frozen(xb", "f_frozen(x",
                               "model(xb, y", "frozen.forward"])
        n_pass = sum([has_deepcopy, has_reset, has_frozen_call])
        if n_pass >= 2:
            score += 0.50
            notes.append("D2 PASS: code shows IT³ structure.")
        elif n_pass == 1:
            score += 0.25
            notes.append("D2 PARTIAL: only partial IT³ structural signals found.")
        else:
            notes.append("D2 FAIL: IT³ structural signals not found.")
    else:
        notes.append("D2 FAIL: run_experiment.py not found.")

    return score, notes


# ── I: Implementation ─────────────────────────────────────────────────────────
def grade_implementation(impl_src):
    """
    I1 (30%): run_it3_ttt() is defined and not raising NotImplementedError.
    I2 (40%): IT³ loss is self-supervised — idempotence pattern detected.
    I3 (30%): Model is reset each batch (load_state_dict inside a loop).
    """
    if impl_src is None:
        return 0.0, ["I: run_experiment.py not found."]

    score = 0.0
    notes = []

    code = "\n".join(
        ln for ln in impl_src.splitlines()
        if ln.strip() and not ln.strip().startswith("#")
    )

    if "raise NotImplementedError" in code:
        notes.append("I: run_it3_ttt() still raises NotImplementedError — not implemented.")
        return 0.0, notes

    # I1
    has_def    = "def run_it3_ttt" in impl_src
    has_return = any(s in impl_src for s in
                     ["return correct", "return float", "return acc", "return corr"])
    if has_def and has_return:
        score += 0.30
        notes.append("I1 PASS: run_it3_ttt() defined with a return statement.")
    elif has_def:
        score += 0.15
        notes.append("I1 PARTIAL: run_it3_ttt() defined but no return detected.")
    else:
        notes.append("I1 FAIL: run_it3_ttt() not found.")

    # I2
    loss_signals = [
        "(y1 - y2)", "(y2 - y1)",
        "y1 - y2", "y2 - y1",
        ".abs().mean()", "abs().mean()",
        "idempotence", "L_IT3",
    ]
    has_idem_loss = any(s in impl_src for s in loss_signals)
    if has_idem_loss:
        score += 0.40
        notes.append("I2 PASS: idempotence loss pattern detected.")
    else:
        notes.append("I2 FAIL: idempotence loss pattern not detected.")

    # I3
    has_reset_in_loop = ("load_state_dict" in impl_src and
                         ("for " in impl_src or "while " in impl_src))
    if has_reset_in_loop:
        score += 0.30
        notes.append("I3 PASS: load_state_dict called inside a loop (per-batch reset).")
    else:
        notes.append("I3 FAIL: load_state_dict not found inside a loop.")

    return score, notes


# ── E: Executability ──────────────────────────────────────────────────────────
def grade_execution(results):
    """
    E1 (50%): baseline_acc is a valid float in [0.30, 0.99].
    E2 (50%): it3_acc is a valid float in [0.30, 0.99].
    """
    if results is None:
        return 0.0, ["E: results.json not found — experiment did not complete."]

    score = 0.0
    notes = []

    b_acc = results.get("baseline_acc")
    i_acc = results.get("it3_acc")

    b_ok = (isinstance(b_acc, (int, float)) and
            ACC_MIN_REASONABLE <= b_acc <= ACC_MAX_REASONABLE)
    i_ok = (isinstance(i_acc, (int, float)) and
            ACC_MIN_REASONABLE <= i_acc <= ACC_MAX_REASONABLE)

    if b_ok:
        score += 0.50
        notes.append(f"E1 PASS: baseline_acc={b_acc:.4f} (reasonable range).")
    elif isinstance(b_acc, (int, float)):
        score += 0.25
        notes.append(f"E1 PARTIAL: baseline_acc={b_acc:.4f} outside "
                     f"[{ACC_MIN_REASONABLE}, {ACC_MAX_REASONABLE}].")
    else:
        notes.append("E1 FAIL: baseline_acc missing or non-numeric.")

    if i_ok:
        score += 0.50
        notes.append(f"E2 PASS: it3_acc={i_acc:.4f} (reasonable range).")
    elif isinstance(i_acc, (int, float)):
        score += 0.25
        notes.append(f"E2 PARTIAL: it3_acc={i_acc:.4f} outside "
                     f"[{ACC_MIN_REASONABLE}, {ACC_MAX_REASONABLE}].")
    else:
        notes.append("E2 FAIL: it3_acc missing or non-numeric.")

    return score, notes


# ── C: Conclusion ─────────────────────────────────────────────────────────────
def grade_conclusion(results):
    """
    C1 (40%): it3_acc > baseline_acc (core paper claim).
    C2 (30%): it3_improves_over_baseline flag is True.
    C3 (30%): conclusion text correctly states IT³ improves accuracy.
    """
    if results is None:
        return 0.0, ["C: results.json not found."]

    score = 0.0
    notes = []

    b_acc = results.get("baseline_acc")
    i_acc = results.get("it3_acc")

    if not (isinstance(b_acc, (int, float)) and isinstance(i_acc, (int, float))):
        notes.append("C: Cannot evaluate — accuracy values missing or non-numeric.")
        return 0.0, notes

    # C1: IT³ beats baseline
    delta = i_acc - b_acc
    if delta > 0:
        score += 0.40
        notes.append(f"C1 PASS: IT³ ({i_acc:.4f}) > baseline ({b_acc:.4f}), "
                     f"delta=+{delta:.4f}.")
    elif abs(delta) <= 0.02:
        score += 0.20
        notes.append(f"C1 PARTIAL: IT³ ({i_acc:.4f}) ≈ baseline ({b_acc:.4f}) "
                     f"(within 0.02).")
    else:
        notes.append(f"C1 FAIL: IT³ ({i_acc:.4f}) ≤ baseline ({b_acc:.4f}).")

    # C2: improves flag
    if results.get("it3_improves_over_baseline") is True:
        score += 0.30
        notes.append("C2 PASS: it3_improves_over_baseline=true.")
    else:
        notes.append(f"C2 FAIL: it3_improves_over_baseline="
                     f"{results.get('it3_improves_over_baseline')}.")

    # C3: conclusion text — must mention IT³ AND a positive outcome without negation
    text = results.get("conclusion", "")
    if isinstance(text, str) and len(text) > 10:
        tl = text.lower()
        has_it3      = any(s in tl for s in ["it³", "it3", "ittt", "it^3"])
        # Check for positive phrases, but not when preceded by "not" or "did not"
        positive_phrases = ["improves", "outperform", "higher", "better",
                            "increases", "surpass", "exceed", "superior"]
        has_positive = any(s in tl for s in positive_phrases)
        has_negation = any(s in tl for s in ["did not improve", "does not improve",
                                              "not improve", "no improvement"])
        if has_it3 and has_positive and not has_negation:
            score += 0.30
            notes.append("C3 PASS: conclusion mentions IT³ and a positive outcome.")
        else:
            notes.append(f"C3 FAIL: conclusion does not clearly state IT³ improves: "
                         f"'{text[:120]}'")
    else:
        notes.append("C3 FAIL: conclusion field missing or too short.")

    return score, notes


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Grade IT³ MNIST Harbor task")
    parser.add_argument("--results", required=True, help="Path to results.json")
    parser.add_argument("--impl",    required=True, help="Path to run_experiment.py")
    args = parser.parse_args()

    results  = load_results(args.results)
    impl_src = load_impl(args.impl)

    d_score, d_notes = grade_design(results, impl_src)
    i_score, i_notes = grade_implementation(impl_src)
    e_score, e_notes = grade_execution(results)
    c_score, c_notes = grade_conclusion(results)

    total = (
        RUBRIC["D"] * d_score
        + RUBRIC["I"] * i_score
        + RUBRIC["E"] * e_score
        + RUBRIC["C"] * c_score
    )

    scores = {
        "D":     round(d_score, 4),
        "I":     round(i_score, 4),
        "E":     round(e_score, 4),
        "C":     round(c_score, 4),
        "total": round(total,   4),
    }

    print("\n" + "=" * 60)
    print("IT³ MNIST Task — Grading Report")
    print("=" * 60)
    for dim, dim_notes in [("D", d_notes), ("I", i_notes),
                           ("E", e_notes), ("C", c_notes)]:
        print(f"\n[{dim}] score = {scores[dim]:.2f} / 1.00  "
              f"(weight {RUBRIC[dim]*100:.0f}%)")
        for note in dim_notes:
            print(f"    {note}")

    print(f"\n{'─'*60}")
    print(f"Weighted total: {scores['total']:.4f}")
    print(f"{'─'*60}\n")
    print(json.dumps(scores))

    os.makedirs("/logs/verifier", exist_ok=True)
    with open("/logs/verifier/reward.json", "w") as f:
        json.dump({"reward": float(scores["total"])}, f)

    sys.exit(0 if scores["total"] > 0 else 1)


if __name__ == "__main__":
    main()
