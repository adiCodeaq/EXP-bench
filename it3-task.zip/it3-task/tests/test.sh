#!/bin/bash
# Verifier entry point for the IT³ tabular Harbor task.
# Runs grade.py, which writes /logs/verifier/reward.json.

mkdir -p /logs/verifier

python /tests/grade.py \
    --results  /workspace/results.json \
    --impl     /workspace/run_experiment.py \
    2>&1 | tee /logs/verifier/grader.log

echo "=== Verifier complete ==="
