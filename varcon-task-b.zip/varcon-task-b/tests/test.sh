#!/bin/bash
mkdir -p /logs/verifier
python /tests/grade.py 2>&1 | tee /logs/verifier/grader.log
