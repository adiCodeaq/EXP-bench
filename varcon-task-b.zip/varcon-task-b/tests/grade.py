#!/usr/bin/env python3
"""
grade.py — Grader for VarCon Task 1B.

Research question: Does the KL divergence term in VarCon's ELBO loss improve
KNN top-1 accuracy on CIFAR-10 compared to training with the NLL term only?

Dimensions (EXP-Bench):
  D (25%) — Experimental design: correct IV (full VarCon vs NLL-only) / DV
            (KNN top-1 accuracy) / constant variables (CIFAR-10, ResNet-50).
  I (35%) — Implementation: D_KL(q_φ || p_θ) implemented via
            F.kl_div(log_p_theta, q_phi, reduction='batchmean', log_target=False).
  E (20%) — Execution: experiment ran, produced valid numeric output.
  C (20%) — Conclusion: full VarCon (KL+NLL) outperforms NLL-only.
"""

import json
import os
import sys

# ── Weights ───────────────────────────────────────────────────────────────────
RUBRIC = {"D": 0.25, "I": 0.35, "E": 0.20, "C": 0.20}

RESULTS_PATH = "/workspace/results.json"
IMPL_PATH    = "/workspace/losses.py"

# Reasonable accuracy range for CIFAR-10 KNN after reduced (10-epoch) training.
ACC_MIN = 0.05    # even early features give some structure on CIFAR-10
ACC_MAX = 0.99


def load_json(path):
    if not os.path.isfile(path):
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def load_text(path):
    if not os.path.isfile(path):
        return None
    with open(path) as f:
        return f.read()


# ── D: Design ─────────────────────────────────────────────────────────────────
def grade_design(results):
    """
    D1 (50%): results.json reports both conditions — varcon_acc (full KL+NLL)
              and no_kl_acc (NLL-only) — i.e. the correct IV/DV comparison.
    D2 (50%): constant variables are correctly fixed (dataset=cifar10,
              model=resnet50) and the directional flag is present.

    Both signals require a completed run, so an untouched stub scores ~0 on D.
    """
    score = 0.0
    notes = []

    if results is None:
        notes.append("D FAIL: results.json not found or invalid — design cannot be verified.")
        return score, notes

    # D1: correct IV / DV — both training conditions reported numerically
    has_v = isinstance(results.get("varcon_acc"), (int, float))
    has_n = isinstance(results.get("no_kl_acc"),  (int, float))
    if has_v and has_n:
        score += 0.50
        notes.append("D1 PASS: results.json reports varcon_acc and no_kl_acc (full vs NLL-only).")
    else:
        missing = [k for k, ok in [("varcon_acc", has_v), ("no_kl_acc", has_n)] if not ok]
        notes.append(f"D1 FAIL: missing numeric keys: {', '.join(missing)}.")

    # D2: constant variables + directional framing
    dataset_ok = str(results.get("dataset", "")).lower() == "cifar10"
    model_ok   = str(results.get("model", "")).lower() == "resnet50"
    flag_ok    = "varcon_outperforms_no_kl" in results
    n_pass = sum([dataset_ok, model_ok, flag_ok])
    if n_pass == 3:
        score += 0.50
        notes.append("D2 PASS: constant vars dataset=cifar10, model=resnet50 and IV framing present.")
    elif n_pass >= 1:
        score += 0.25
        notes.append(f"D2 PARTIAL: only {n_pass}/3 design metadata signals correct "
                     f"(dataset={results.get('dataset')}, model={results.get('model')}, "
                     f"flag_present={flag_ok}).")
    else:
        notes.append("D2 FAIL: constant-variable metadata absent or incorrect.")

    return score, notes


# ── I: Implementation ─────────────────────────────────────────────────────────
def grade_implementation(impl_src):
    """
    I1 (30%): the KL stub is resolved (no NotImplementedError remains).
    I2 (40%): KL term implemented with F.kl_div over log_p_theta and q_phi.
    I3 (30%): matches Eq. 7 / instructions — reduction='batchmean', log_target=False.
    """
    if impl_src is None:
        return 0.0, ["I: losses.py not found."]

    score = 0.0
    notes = []
    c = impl_src
    cl = c.lower()

    # Stub still active? (masked file's NotImplementedError for the KL term)
    stub_active = (
        "raise NotImplementedError" in c
        and "implement the kl divergence" in cl
    )
    if stub_active:
        notes.append("I: KL-divergence stub still active (NotImplementedError not removed).")
        return 0.0, notes

    # I1: stub resolved
    if "raise NotImplementedError" not in c:
        score += 0.30
        notes.append("I1 PASS: forward() does not raise NotImplementedError.")
    else:
        score += 0.15
        notes.append("I1 PARTIAL: NotImplementedError present but not the KL stub.")

    # I2: KL term via F.kl_div over log_p_theta and q_phi
    uses_kl_div = ("kl_div" in cl) and ("f.kl_div" in cl or "kl_div(" in cl)
    refs_args   = ("log_p_theta" in c) and ("q_phi" in c)
    if uses_kl_div and refs_args:
        score += 0.40
        notes.append("I2 PASS: KL term computed with F.kl_div over log_p_theta and q_phi.")
    elif uses_kl_div:
        score += 0.20
        notes.append("I2 PARTIAL: F.kl_div used but expected arguments not both referenced.")
    else:
        notes.append("I2 FAIL: F.kl_div over (log_p_theta, q_phi) not found.")

    # I3: correct reduction / target form
    has_batchmean = "batchmean" in cl
    has_logtarget = "log_target" in cl
    if has_batchmean and has_logtarget:
        score += 0.30
        notes.append("I3 PASS: reduction='batchmean' and log_target specified (Eq. 7 form).")
    elif has_batchmean:
        score += 0.15
        notes.append("I3 PARTIAL: reduction='batchmean' present but log_target not specified.")
    else:
        notes.append("I3 FAIL: KL reduction does not match the expected 'batchmean' form.")

    return score, notes


# ── E: Execution ──────────────────────────────────────────────────────────────
def grade_execution(results):
    """
    E1 (50%): varcon_acc is a valid float in [ACC_MIN, ACC_MAX].
    E2 (50%): no_kl_acc  is a valid float in [ACC_MIN, ACC_MAX].
    """
    if results is None:
        return 0.0, ["E: results.json not found — experiment did not complete."]

    score = 0.0
    notes = []

    for key, label, weight in [("varcon_acc", "E1", 0.50), ("no_kl_acc", "E2", 0.50)]:
        val = results.get(key)
        if isinstance(val, (int, float)) and ACC_MIN <= val <= ACC_MAX:
            score += weight
            notes.append(f"{label} PASS: {key}={val:.4f} (in valid range).")
        elif isinstance(val, (int, float)):
            score += weight * 0.5
            notes.append(f"{label} PARTIAL: {key}={val:.4f} outside [{ACC_MIN}, {ACC_MAX}].")
        else:
            notes.append(f"{label} FAIL: {key} missing or non-numeric.")

    return score, notes


# ── C: Conclusion ─────────────────────────────────────────────────────────────
def grade_conclusion(results):
    """
    C1 (40%): varcon_acc > no_kl_acc (directional; lenient 5pp tolerance).
    C2 (30%): varcon_outperforms_no_kl flag is True.
    C3 (30%): conclusion text states the KL term / full VarCon outperforms.
    """
    if results is None:
        return 0.0, ["C: results.json not found."]

    score = 0.0
    notes = []

    va = results.get("varcon_acc")
    na = results.get("no_kl_acc")

    if not (isinstance(va, (int, float)) and isinstance(na, (int, float))):
        notes.append("C: accuracy values missing or non-numeric — cannot evaluate.")
        return 0.0, notes

    # C1: directional claim (lenient: allow up to 5pp in wrong direction)
    delta = va - na
    if delta > 0:
        score += 0.40
        notes.append(f"C1 PASS: varcon_acc ({va:.4f}) > no_kl_acc ({na:.4f}), Δ={delta*100:+.2f}pp.")
    elif delta > -0.05:
        score += 0.20
        notes.append(f"C1 PARTIAL: varcon_acc ({va:.4f}) within 5pp of no_kl_acc ({na:.4f}).")
    else:
        notes.append(f"C1 FAIL: varcon_acc ({va:.4f}) < no_kl_acc ({na:.4f}) by {abs(delta)*100:.2f}pp.")

    # C2: flag
    if results.get("varcon_outperforms_no_kl") is True:
        score += 0.30
        notes.append("C2 PASS: varcon_outperforms_no_kl = true.")
    else:
        notes.append(f"C2 FAIL: varcon_outperforms_no_kl = {results.get('varcon_outperforms_no_kl')}.")

    # C3: conclusion text references the paper's claim
    text = results.get("conclusion", "")
    if isinstance(text, str) and len(text) > 20:
        tl = text.lower()
        has_subject  = any(s in tl for s in ["kl", "varcon", "elbo", "divergence"])
        has_positive = any(s in tl for s in ["outperform", "higher", "better", "improves",
                                             "surpass", "superior", "95.94", "contribute"])
        has_negation = any(s in tl for s in ["does not outperform", "did not outperform",
                                             "not better", "underperforms"])
        if has_subject and has_positive and not has_negation:
            score += 0.30
            notes.append("C3 PASS: conclusion states KL/VarCon yields a positive outcome.")
        elif has_subject or has_positive:
            score += 0.15
            notes.append("C3 PARTIAL: conclusion partially states the claim.")
        else:
            notes.append(f"C3 FAIL: conclusion does not state the claim: '{text[:120]}'")
    else:
        notes.append("C3 FAIL: conclusion field missing or too short.")

    return score, notes


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    results  = load_json(RESULTS_PATH)
    impl_src = load_text(IMPL_PATH)

    d_score, d_notes = grade_design(results)
    i_score, i_notes = grade_implementation(impl_src)
    e_score, e_notes = grade_execution(results)
    c_score, c_notes = grade_conclusion(results)

    total = (
        RUBRIC["D"] * d_score
        + RUBRIC["I"] * i_score
        + RUBRIC["E"] * e_score
        + RUBRIC["C"] * c_score
    )

    scores = {
        "D":     round(d_score, 4),
        "I":     round(i_score, 4),
        "E":     round(e_score, 4),
        "C":     round(c_score, 4),
        "total": round(total,   4),
    }

    print("\n" + "=" * 60)
    print("VarCon Task 1B — Grading Report")
    print("=" * 60)
    for dim, dim_notes in [("D", d_notes), ("I", i_notes),
                            ("E", e_notes), ("C", c_notes)]:
        print(f"\n[{dim}] score = {scores[dim]:.2f} / 1.00  "
              f"(weight {RUBRIC[dim]*100:.0f}%)")
        for note in dim_notes:
            print(f"    {note}")

    print(f"\n{'─'*60}")
    print(f"Weighted total: {scores['total']:.4f}")
    print(f"{'─'*60}\n")
    print(json.dumps(scores))

    os.makedirs("/logs/verifier", exist_ok=True)
    with open("/logs/verifier/reward.json", "w") as f:
        json.dump({"reward": float(scores["total"])}, f)

    sys.exit(0 if scores["total"] > 0 else 1)


if __name__ == "__main__":
    main()
