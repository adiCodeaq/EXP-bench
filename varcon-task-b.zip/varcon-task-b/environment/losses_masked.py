from __future__ import print_function

import torch
import torch.nn as nn
import torch.nn.functional as F


class VarConLoss(nn.Module):
    """
    VarCon: Variational Supervised Contrastive Learning

    Loss definition (per sample, averaged over batch):
        L_VarCon = D_KL(q_φ(r'|z) || p_θ(r'|z)) - log p_θ(r|z)

    where
        p_θ(r|z)        = exp(z^T w_r / τ₁) / Σ_{r'} exp(z^T w_{r'} / τ₁)   (Eq. 8)
        q_one-hot(r'|z) = 1 if r' = r else 0                                (Eq. 10)
        q_exp(r'|z)     = 1 + [exp(1/τ₂) - 1] · q_one-hot(r'|z)             (Eq. 11)
        q_φ(r'|z)       = q_exp(r'|z) / Σ_{r'} q_exp(r'|z)                  (Eq. 12)
        τ₂              = (τ₁ - ε) + 2ε · p_θ(r|z)                          (Eq. 13)

    Args (init):
        num_classes:    total number of classes
        feat_dim:       feature dimension
        temperature:    τ₁, temperature used in p_θ
        epsilon:        ε, adaptive temperature strength
        normalize:      whether to L2-normalize centroids
        use_kl:         if True, compute D_KL(q||p); if False, KL term is zero (NLL-only)
    """
    def __init__(
        self,
        num_classes: int = 1000,
        feat_dim: int = 128,
        temperature: float = 0.1,
        epsilon: float = 0.02,
        normalize: bool = True,
        use_kl: bool = True,
    ):
        super().__init__()
        self.tau1 = temperature
        self.normalize = normalize
        self.num_classes = num_classes
        self.feat_dim = feat_dim
        self.epsilon = epsilon
        self.use_kl = use_kl

    def forward(self, features: torch.Tensor, labels: torch.Tensor):
        """
        Args:
            features: [B, feat_dim]  L2-normalized encoder output features
            labels:   [B]            integer class labels

        Returns:
            dict with:
                'total_loss': batch-averaged VarCon loss (scalar)
                'kl_div':     KL(q||p) term (detached scalar)
                'nll':        -log p_θ(r|z) term (detached scalar)
                'avg_tau2':   average τ₂ over batch
                'avg_confidence': average p_θ(r|z) over batch
        """
        device = features.device
        B = features.shape[0]

        # Compute centroid for each class in batch
        unique_labels, inverse_indices = torch.unique(labels, return_inverse=True)
        C_batch = len(unique_labels)

        # one_hot: [B, C_batch]
        one_hot = torch.zeros(B, C_batch, device=device)
        one_hot.scatter_(1, inverse_indices.unsqueeze(1), 1.0)

        # class counts: [C_batch]
        class_counts = one_hot.sum(dim=0).clamp(min=1)

        # centroids: [C_batch, feat_dim]
        centroids = one_hot.T @ features / class_counts.unsqueeze(1)

        if self.normalize:
            centroids = F.normalize(centroids, p=2, dim=1)

        centroids = centroids.detach()

        # logits: z^T w_r / τ₁ (Eq. 8)
        logits = features @ centroids.T / self.tau1  # [B, C_batch]

        # p_θ(r|z) — softmax over classes (Eq. 8)
        p_theta = F.softmax(logits, dim=1)  # [B, C_batch]
        # Confidence p_θ(r|z) for true class: [B]
        confidences = p_theta.gather(1, inverse_indices.unsqueeze(1)).squeeze(1)

        # τ₂ (Eq. 13) — confidence-adaptive temperature
        eps = self.epsilon
        tau2 = (self.tau1 - eps) + 2.0 * eps * confidences  # [B]
        tau2 = torch.clamp(tau2, min=1e-6)

        # q_φ (Eqs. 10, 11, 12)
        exp_inv_tau2 = torch.exp(1.0 / tau2)               # [B]
        q_exp = 1.0 + (exp_inv_tau2.unsqueeze(1) - 1.0) * one_hot  # [B, C_batch]
        q_phi = q_exp / q_exp.sum(dim=1, keepdim=True)     # normalize to probability

        # Loss (Eq. 7)
        log_p_theta = F.log_softmax(logits, dim=1)         # [B, C_batch]

        if self.use_kl:
            # ================================================================
            # YOUR TASK: implement the KL divergence term D_KL(q_φ || p_θ)
            #
            # The KL divergence term in the ELBO loss (Eq. 7):
            #     D_KL(q_φ(r'|z) || p_θ(r'|z))
            #
            # Use torch.nn.functional.kl_div with:
            #   - first argument:  log_p_theta  (log p, shape [B, C_batch])
            #   - second argument: q_phi        (q, shape [B, C_batch])
            #   - reduction='batchmean'
            #   - log_target=False  (q_phi is not in log-space)
            #
            # F.kl_div(log_p, q, reduction='batchmean') computes:
            #     mean over batch of: sum_r' [ q(r') * (log q(r') - log_p(r')) ]
            #                       = KL(q || p)
            # ================================================================
            raise NotImplementedError(
                "Implement the KL divergence term D_KL(q_φ || p_θ).\n"
                "Use: kl_div = F.kl_div(log_p_theta, q_phi,\n"
                "                       reduction='batchmean', log_target=False)"
            )
        else:
            kl_div = torch.tensor(0.0, device=device)

        # NLL: -log p_θ(r|z)
        nll = -log_p_theta.gather(1, inverse_indices.unsqueeze(1)).mean()

        loss = kl_div + nll

        return {
            'total_loss': loss,
            'kl_div': kl_div.detach() if isinstance(kl_div, torch.Tensor) else kl_div,
            'nll': nll.detach(),
            'avg_tau2': tau2.mean().detach(),
            'avg_confidence': confidences.mean().detach(),
        }
