#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Install the complete losses.py (KL divergence correctly implemented)
cp "${SCRIPT_DIR}/losses_complete.py" /workspace/losses.py

# Run the experiment: full VarCon (KL+NLL) vs NLL-only on CIFAR-10
python /workspace/run_experiment.py
