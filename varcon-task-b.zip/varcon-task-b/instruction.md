# Research Task: VarCon KL Divergence Term on CIFAR-10

## Research Question

Does the KL divergence term in VarCon's ELBO loss improve KNN top-1 accuracy
on CIFAR-10 compared to training with the NLL term only?

## Background

**VarCon** derives its training objective from maximizing an evidence lower bound
(ELBO). The final contrastive-relevant loss is (Eq. 7):

```
L_VarCon = D_KL(q_φ(r'|z) || p_θ(r'|z))  −  log p_θ(r|z)
           ────────────────────────────────    ──────────────
                  KL divergence term               NLL term
```

The two terms play complementary roles:

| Term | Role |
|------|------|
| **KL divergence** | Aligns the auxiliary distribution `q_φ` with the model's posterior `p_θ`, enforcing distributional consistency and preventing representational collapse |
| **NLL** (negative log-posterior) | Encourages correct class centroid attraction — pulls `z` toward its true class centroid `w_r` |

The paper argues that the KL term provides the alignment signal that shapes inter-class
structure, while NLL alone is insufficient to organize the embedding space.

**Note on ground truth**: The VarCon paper (NeurIPS 2025) does not include an explicit
"w/o KL" ablation table row with classification accuracy. The task uses the full VarCon
result (95.94% on CIFAR-10, Table 1) as the upper bound and measures the drop when the
KL term is removed. The paper's supplementary analysis (Appendix B.4) confirms that
"both components contribute to superior performance."

## Repository and File Structure

```
/workspace/
├── losses.py          ← EDIT THIS FILE (KL divergence term is stubbed out)
├── run_experiment.py  ← Run this to evaluate; do NOT modify
├── util.py
└── networks/
    └── resnet_big.py
```

The file `/workspace/losses.py` contains the `VarConLoss` class.
Inside `VarConLoss.forward()`, the **KL divergence computation has been removed**
and replaced with a stub that raises `NotImplementedError`.

## Step-by-Step Instructions

### Step 1: Understand VarConLoss.forward() in losses.py

Read the `forward()` method. The flow is:

1. Compute class centroids `w_r` from the batch features
2. Compute logits and posterior `p_θ(r|z)`
3. Compute confidence-adaptive temperature `τ₂`
4. Compute soft target distribution `q_φ` using τ₂ (Eqs. 10–12)
5. **STUB HERE**: Compute `kl_div = D_KL(q_φ || p_θ)` ← you must implement this
6. Compute NLL: `nll = -log p_θ(r|z)`
7. Combine: `loss = kl_div + nll`

### Step 2: Implement the KL Divergence Term

Find the stub and replace it with:

```python
kl_div = F.kl_div(
    log_p_theta,      # log p_θ(r'|z)  — shape [B, C_batch]
    q_phi,            # q_φ(r'|z)      — shape [B, C_batch]
    reduction='batchmean',
    log_target=False,
)
```

`log_p_theta` is `F.log_softmax(logits, dim=1)` — already computed above the stub.
`q_phi` is the normalized soft target distribution — already computed above the stub.

`F.kl_div` computes `KL(q || p)` as:
```
sum(q * (log(q) - input))  = sum(q * log(q/p))
```
where `input` is `log(p)` and `q` is the target.

### Step 3: Run the Experiment

```bash
cd /workspace
python run_experiment.py
```

The script trains two ResNet-50 models on CIFAR-10 (reduced epochs for
pipeline verification):
1. **Full VarCon** (KL + NLL): the complete ELBO objective
2. **NLL-only** baseline: KL term zeroed out during training

After training, it evaluates KNN top-1 accuracy (k=200) and saves results
to `/workspace/results.json`.

### Step 4: Check Results

The output `/workspace/results.json` should look like:

```json
{
  "varcon_acc": 0.7341,
  "no_kl_acc": 0.6987,
  "delta_pp": 3.54,
  "varcon_outperforms_no_kl": true,
  "paper_varcon_acc": 0.9594,
  "n_epochs": 10,
  "dataset": "cifar10",
  "model": "resnet50",
  "knn_k": 200,
  "conclusion": "..."
}
```

## Expected Outcome

- **Paper result** (200 epochs, full model): VarCon 95.94% on CIFAR-10 (Table 1)
- **Pipeline run** (10 epochs): Full VarCon should outperform NLL-only on KNN accuracy
- **Key insight**: the KL divergence aligns the auxiliary distribution with the model's
  posterior, providing distributional structure that the NLL term alone cannot achieve

## Variable Classifications

- **Independent variable**: full VarCon (KL + NLL) vs NLL-only
- **Dependent variable**: KNN top-1 accuracy on CIFAR-10
- **Constant variables**: dataset=CIFAR-10, model=ResNet-50, augmentation, τ₁=0.1, ε=0.02

## Deviation Note

The original task referenced a "w/o KL" ablation row in the VarCon paper. After reviewing
the complete paper, **no such ablation table exists**. The task is therefore adjusted to
run the ablation from scratch, comparing the full ELBO objective against NLL-only training,
using VarCon Table 1 (95.94% CIFAR-10) as the upper bound ground truth.
