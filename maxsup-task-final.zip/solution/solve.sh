#!/bin/bash
# Ground-truth solution script for the MaxSup CIFAR-10-LT Harbor task.
# Copies MAXsupLoss.py into place, trains all three methods, and saves results.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="/workspace/Maximum-Suppression-Regularization"
LT_DIR="${REPO_ROOT}/LT"
RESULTS_FILE="/workspace/results.json"

# ── Step 1: Copy the MaxSup loss implementation into the repo ────────────────
echo "=== Copying MAXsupLoss.py ==="
cp "${SCRIPT_DIR}/MAXsupLoss.py" "${LT_DIR}/loss/MAXsupLoss.py"

cd "${LT_DIR}"

# ── Step 2: Train all three methods ─────────────────────────────────────────
echo "=== Training MaxSup (imbalance ratio 50) ==="
python main.py --cfg ./config/CIFAR10_LT/causal_norm_32_maxsup_imb50.yaml 2>&1 \
    | tee /tmp/log_maxsup.txt

echo "=== Training Label Smoothing (imbalance ratio 50) ==="
python main.py --cfg ./config/CIFAR10_LT/causal_norm_32_ls_imb50.yaml 2>&1 \
    | tee /tmp/log_ls.txt

echo "=== Training Focal Loss (imbalance ratio 50) ==="
python main.py --cfg ./config/CIFAR10_LT/causal_norm_32_focal_imb50.yaml 2>&1 \
    | tee /tmp/log_focal.txt

# ── Step 3: Extract results and write results.json ───────────────────────────
echo "=== Parsing results ==="
python3 "${SCRIPT_DIR}/parse_results.py" \
    --lt_dir "${LT_DIR}" \
    --output "${RESULTS_FILE}"

echo "=== solve.sh complete ==="
