# ./loss/MAXsupLoss.py
import torch
import torch.nn as nn
import torch.nn.functional as F


class MaxSupLoss(nn.Module):
    def __init__(self, num_epochs=200):
        super().__init__()
        self.epoch = 0
        self.total_epochs = num_epochs
        self.ce = nn.CrossEntropyLoss(label_smoothing=0.0)

    def set_epoch(self, epoch):
        """Update epoch counter for the alpha scheduler (called each epoch)."""
        self.epoch = epoch

    def forward(self, x, target):
        """
        Compute total MaxSup loss.

        Args:
            x      : logits tensor, shape (batch_size, num_classes)
            target : ground-truth class indices, shape (batch_size,)

        Returns:
            Scalar loss = CE(x, target) + alpha * mean(z_max - mean(z))
        """
        loss_ce = self.ce(x, target)
        z_top1 = x.topk(1, dim=-1)[0]                          # (batch, 1)
        reg = z_top1 - x.mean(dim=-1, keepdim=True)            # (batch, 1)
        lam = 0.1 + 0.1 * self.epoch / max(1, self.total_epochs - 1)
        return loss_ce + lam * reg.mean()


def create_loss(num_epochs=200):
    """Factory function called by the training framework (no positional args)."""
    print(f"Loading MaxSup Loss with total_epochs={num_epochs}")
    return MaxSupLoss(num_epochs=num_epochs)
