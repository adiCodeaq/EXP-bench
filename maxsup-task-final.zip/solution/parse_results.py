#!/usr/bin/env python3
"""
parse_results.py — Extract test metrics from training logs and write results.json.

Usage:
    python parse_results.py --lt_dir /workspace/Maximum-Suppression-Regularization/LT \
                            --output /workspace/results.json
"""

import argparse
import json
import re
import os


LOG_PATHS = {
    "maxsup": "logs/CIFAR10_LT/models/resnet32_e200_warmup_causal_norm_ratio50_maxsup/log.txt",
    "ls":     "logs/CIFAR10_LT/models/resnet32_e200_warmup_causal_norm_ratio50_ls/log.txt",
    "focal":  "logs/CIFAR10_LT/models/resnet32_e200_warmup_causal_norm_ratio50_focal/log.txt",
}


def parse_test_metrics(log_path):
    """Parse the final test-phase metrics from a log.txt file."""
    with open(log_path) as f:
        content = f.read()

    # Grab the last "Phase: test" block (training logs val each epoch, test once at end)
    sections = content.split("Phase: test")
    if len(sections) < 2:
        return None
    last = sections[-1]

    def first_float(pattern, text):
        m = re.search(pattern, text)
        return float(m.group(1)) * 100 if m else None

    return {
        "overall": first_float(r"Evaluation_accuracy_micro_top1:\s+([\d.]+)", last),
        "many":    first_float(r"Many_shot_accuracy_top1:\s+([\d.]+)", last),
        "medium":  first_float(r"Median_shot_accuracy_top1:\s+([\d.]+)", last),
        "low":     first_float(r"Low_shot_accuracy_top1:\s+([\d.]+)", last),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lt_dir", required=True, help="Path to the LT/ working directory")
    parser.add_argument("--output", default="/workspace/results.json", help="Path to write results.json")
    args = parser.parse_args()

    results = {}
    for method, rel_path in LOG_PATHS.items():
        log_path = os.path.join(args.lt_dir, rel_path)
        results[method] = parse_test_metrics(log_path)

    maxsup_acc = results["maxsup"]["overall"] if results["maxsup"] else None
    ls_acc     = results["ls"]["overall"]     if results["ls"]     else None
    focal_acc  = results["focal"]["overall"]  if results["focal"]  else None

    if maxsup_acc is not None and ls_acc is not None:
        delta = maxsup_acc - ls_acc
        conclusion = (
            f"MaxSup achieves {maxsup_acc:.1f}% overall test accuracy on CIFAR-10-LT "
            f"(imbalance ratio 50), outperforming Label Smoothing ({ls_acc:.1f}%) by "
            f"{delta:.1f} percentage points"
        )
        if focal_acc is not None:
            conclusion += f" and Focal Loss ({focal_acc:.1f}%)."
        else:
            conclusion += "."
    else:
        conclusion = "Results could not be fully extracted."

    results["conclusion"] = conclusion

    print(json.dumps(results, indent=2))
    with open(args.output, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to {args.output}")


if __name__ == "__main__":
    main()
