# ./loss/MAXsupLoss.py
#
# TODO: Implement Max Suppression Regularization Loss
#
# Based on: "MaxSup: Overcoming Representation Collapse in Label Smoothing"
# NeurIPS 2025 Oral  —  https://github.com/ZhouYuxuanYX/Maximum-Suppression-Regularization
#
# MaxSup replaces Label Smoothing's penalty on the ground-truth logit z_gt
# with a penalty on the top-1 logit z_max, eliminating the error amplification
# that LS introduces when the model misclassifies a sample.
#
# Formula:
#   L_total = CrossEntropy(logits, labels)
#           + alpha * mean_over_batch( z_max - mean_over_classes(z) )
#
# where:
#   z_max   = highest logit per sample  (shape: [batch, 1])
#   mean(z) = mean logit per sample across all K classes  (shape: [batch, 1])
#   alpha   = regularisation weight
#             (linearly increases from 0.1 → 0.2 over training via set_epoch)
#
# See LSLoss.py in the same directory for an example module structure.

import torch
import torch.nn as nn
import torch.nn.functional as F


class MaxSupLoss(nn.Module):
    def __init__(self, num_epochs=200):
        super().__init__()
        # TODO: store num_epochs, initialise epoch counter, initialise CE loss
        raise NotImplementedError("Implement MaxSupLoss.__init__")

    def set_epoch(self, epoch):
        """Update epoch counter for the alpha scheduler (called each epoch)."""
        # TODO: update self.epoch
        pass

    def forward(self, x, target):
        """
        Compute total MaxSup loss.

        Args:
            x      : logits tensor, shape (batch_size, num_classes)
            target : ground-truth class indices, shape (batch_size,)

        Returns:
            Scalar loss.
        """
        # TODO: implement
        #   1. CE loss: standard cross-entropy, no label smoothing
        #   2. MaxSup reg: alpha * mean_batch(z_max - mean_classes(z))
        #      where z_max = x.topk(1, dim=-1)[0]  [top-1 logit per sample]
        #   3. return CE + MaxSup reg
        raise NotImplementedError("Implement MaxSupLoss.forward")


def create_loss(num_epochs=200):
    """Factory function called by the training framework (no positional args)."""
    print(f"Loading MaxSup Loss with total_epochs={num_epochs}")
    return MaxSupLoss(num_epochs=num_epochs)
