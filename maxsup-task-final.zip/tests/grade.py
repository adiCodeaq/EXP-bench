#!/usr/bin/env python3
"""
grade.py — Grader for the MaxSup CIFAR-10-LT Harbor task.

Evaluates four dimensions:
  D  Design correctness     — correct experimental setup / variable identification
  I  Implementation         — correct MaxSup loss implementation
  E  Executability          — both MaxSup and LS training runs completed
  C  Conclusion correctness — MaxSup outperforms LS on test overall accuracy

Usage:
  python grade.py --results /workspace/results.json \
                  --impl /workspace/Maximum-Suppression-Regularization/LT/loss/MAXsupLoss.py
"""

import argparse
import ast
import json
import os
import re
import sys
import textwrap
import importlib.util

# ── Ground-truth reference values (paper Table 7, imbalance ratio 50, test) ──
GT = {
    "maxsup": {"overall": 81.4, "many": 82.3, "medium": 73.4, "low": 0.0},
    "ls":     {"overall": 80.5, "many": 81.1, "medium": 75.4, "low": 0.0},
    "focal":  {"overall": 76.8, "many": 75.3, "medium": 90.4, "low": 0.0},
}

# Tolerance for numerical comparisons (percentage points)
TOLERANCE = 2.0

# ── Rubric weights ────────────────────────────────────────────────────────────
RUBRIC = {
    "D": 0.25,   # Design
    "I": 0.35,   # Implementation
    "E": 0.20,   # Executability
    "C": 0.20,   # Conclusion
}


def load_results(path):
    if not os.path.isfile(path):
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def load_impl_source(path):
    if not os.path.isfile(path):
        return None
    with open(path) as f:
        return f.read()


# ── D: Design correctness ─────────────────────────────────────────────────────
def grade_design(results, impl_src):
    """
    Checks whether the agent understood the experimental design:
      D1 (50%) – experiment compares MaxSup vs LS (and ideally Focal) with the
                 correct dataset / architecture settings present in results.json
      D2 (50%) – the agent's code or results demonstrate awareness that MaxSup
                 penalises the TOP-1 logit (z_max), not the ground-truth logit (z_gt)
    """
    score = 0.0
    notes = []

    # D1: results.json has entries for maxsup and ls with non-null overall accuracy
    if results is not None:
        has_maxsup = (
            "maxsup" in results
            and isinstance(results["maxsup"], dict)
            and results["maxsup"].get("overall") is not None
        )
        has_ls = (
            "ls" in results
            and isinstance(results["ls"], dict)
            and results["ls"].get("overall") is not None
        )
        if has_maxsup and has_ls:
            score += 0.50
            notes.append("D1 PASS: results.json contains maxsup and ls entries with overall accuracy.")
        else:
            notes.append("D1 FAIL: results.json missing maxsup or ls entries.")
    else:
        notes.append("D1 FAIL: results.json not found or invalid.")

    # D2: implementation code (non-comment lines) references top-1 logit selection
    if impl_src is not None:
        # Strip comment-only lines so stub comments don't count
        code_lines = [
            ln for ln in impl_src.splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        ]
        code_only = "\n".join(code_lines)
        top1_signals = ["topk", "z_max", "zmax", "top_1", ".max(", "argmax"]
        if any(sig in code_only for sig in top1_signals):
            score += 0.50
            notes.append("D2 PASS: implementation code references top-1 logit selection.")
        else:
            notes.append("D2 FAIL: no top-1 logit selection found in non-comment code.")
    else:
        notes.append("D2 FAIL: MAXsupLoss.py not found.")

    return score, notes


# ── I: Implementation correctness ────────────────────────────────────────────
def grade_implementation(impl_src):
    """
    Checks the MAXsupLoss.py implementation:
      I1 (30%) – class structure is correct: inherits nn.Module, has forward() and create_loss()
      I2 (40%) – forward() computes CE loss (not just MSE etc.)
      I3 (30%) – regularization term is z_max - mean(z), applied to all samples
    """
    if impl_src is None:
        return 0.0, ["I: MAXsupLoss.py not found — 0/3 sub-criteria."]

    score = 0.0
    notes = []

    # Check for stub / not implemented
    if "raise NotImplementedError" in impl_src and "forward" in impl_src:
        # If the forward still raises, the implementation is incomplete
        # We check whether __init__ also raises; if so, entirely unimplemented
        src_stripped = impl_src.replace(" ", "").lower()
        if src_stripped.count("raisenotimplementederror") >= 2:
            notes.append("I: Implementation appears to be the unmodified stub (still raises NotImplementedError).")
            return 0.0, notes

    # I1: class structure
    has_module = "nn.Module" in impl_src
    has_forward = "def forward" in impl_src
    has_create  = "def create_loss" in impl_src
    if has_module and has_forward and has_create:
        score += 0.30
        notes.append("I1 PASS: correct class structure (nn.Module, forward, create_loss).")
    else:
        missing = []
        if not has_module: missing.append("nn.Module inheritance")
        if not has_forward: missing.append("forward()")
        if not has_create:  missing.append("create_loss()")
        notes.append(f"I1 PARTIAL/FAIL: missing {', '.join(missing)}.")
        score += 0.30 * (sum([has_module, has_forward, has_create]) / 3)

    # I2: CE loss usage
    ce_signals = [
        "CrossEntropyLoss", "cross_entropy", "F.cross_entropy",
        "nn.CrossEntropyLoss", "nll_loss", "log_softmax",
    ]
    if any(s in impl_src for s in ce_signals):
        score += 0.40
        notes.append("I2 PASS: CE loss component found.")
    else:
        notes.append("I2 FAIL: no CE loss component detected.")

    # I3: regularization is zmax - mean(z) style
    reg_signals = [
        "topk", ".max(", "argmax",    # selecting z_max
    ]
    mean_signals = [
        ".mean(", "mean(x", "mean(z",  # computing mean logit
    ]
    has_top1 = any(s in impl_src for s in reg_signals)
    has_mean = any(s in impl_src for s in mean_signals)
    if has_top1 and has_mean:
        score += 0.30
        notes.append("I3 PASS: regularization uses z_max and mean(z).")
    elif has_top1 or has_mean:
        score += 0.15
        notes.append("I3 PARTIAL: only one of z_max / mean(z) detected.")
    else:
        notes.append("I3 FAIL: MaxSup regularization term not detected.")

    return score, notes


# ── E: Executability ──────────────────────────────────────────────────────────
def grade_execution(results):
    """
    Checks whether training completed and produced valid outputs.
      E1 (50%) – MaxSup training produced a non-null overall accuracy
      E2 (50%) – LS training produced a non-null overall accuracy
    """
    if results is None:
        return 0.0, ["E: results.json not found — training did not complete."]

    score = 0.0
    notes = []

    maxsup_ok = (
        "maxsup" in results
        and isinstance(results["maxsup"], dict)
        and isinstance(results["maxsup"].get("overall"), (int, float))
    )
    ls_ok = (
        "ls" in results
        and isinstance(results["ls"], dict)
        and isinstance(results["ls"].get("overall"), (int, float))
    )

    if maxsup_ok:
        score += 0.50
        notes.append(f"E1 PASS: MaxSup training completed, overall={results['maxsup']['overall']:.1f}%.")
    else:
        notes.append("E1 FAIL: MaxSup overall accuracy missing from results.")

    if ls_ok:
        score += 0.50
        notes.append(f"E2 PASS: LS training completed, overall={results['ls']['overall']:.1f}%.")
    else:
        notes.append("E2 FAIL: LS overall accuracy missing from results.")

    return score, notes


# ── C: Conclusion correctness ─────────────────────────────────────────────────
def grade_conclusion(results):
    """
    Checks whether the agent reached the correct scientific conclusion.
      C1 (40%) – MaxSup numerically outperforms LS (overall > ls overall)
      C2 (30%) – MaxSup accuracy is within TOLERANCE of the paper's reported value
      C3 (30%) – conclusion text (if present) correctly states MaxSup > LS
    """
    if results is None:
        return 0.0, ["C: results.json not found."]

    score = 0.0
    notes = []

    maxsup_acc = results.get("maxsup", {}).get("overall") if results.get("maxsup") else None
    ls_acc     = results.get("ls", {}).get("overall")     if results.get("ls")     else None

    if maxsup_acc is None or ls_acc is None:
        notes.append("C: Cannot evaluate — accuracy values missing.")
        return 0.0, notes

    # C1: MaxSup > LS numerically
    if maxsup_acc > ls_acc:
        score += 0.40
        notes.append(f"C1 PASS: MaxSup ({maxsup_acc:.1f}%) > LS ({ls_acc:.1f}%).")
    elif abs(maxsup_acc - ls_acc) <= 0.5:
        score += 0.20
        notes.append(f"C1 PARTIAL: MaxSup ({maxsup_acc:.1f}%) ≈ LS ({ls_acc:.1f}%) (within 0.5pp).")
    else:
        notes.append(f"C1 FAIL: MaxSup ({maxsup_acc:.1f}%) did not outperform LS ({ls_acc:.1f}%).")

    # C2: MaxSup accuracy close to paper's reported value (81.4%)
    gt_maxsup = GT["maxsup"]["overall"]
    if abs(maxsup_acc - gt_maxsup) <= TOLERANCE:
        score += 0.30
        notes.append(f"C2 PASS: MaxSup accuracy {maxsup_acc:.1f}% within {TOLERANCE}pp of paper ({gt_maxsup}%).")
    else:
        diff = abs(maxsup_acc - gt_maxsup)
        notes.append(f"C2 FAIL: MaxSup accuracy {maxsup_acc:.1f}% differs from paper ({gt_maxsup}%) by {diff:.1f}pp.")

    # C3: conclusion text asserts MaxSup > LS
    conclusion_text = results.get("conclusion", "")
    if isinstance(conclusion_text, str) and len(conclusion_text) > 10:
        text_lower = conclusion_text.lower()
        positive_signals = ["outperform", "higher", "better", "surpass", "improve", "exceed", "superior"]
        maxsup_mentioned = "maxsup" in text_lower
        positive_claim   = any(s in text_lower for s in positive_signals)
        ls_mentioned     = "label smooth" in text_lower or " ls " in text_lower or "ls," in text_lower
        if maxsup_mentioned and positive_claim:
            score += 0.30
            notes.append("C3 PASS: conclusion text states MaxSup outperforms LS.")
        else:
            notes.append(f"C3 FAIL: conclusion text does not clearly state MaxSup > LS: '{conclusion_text[:120]}'")
    else:
        notes.append("C3 FAIL: conclusion text missing or too short.")

    return score, notes


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Grade MaxSup CIFAR-10-LT Harbor task")
    parser.add_argument("--results", required=True, help="Path to results.json")
    parser.add_argument("--impl",    required=True, help="Path to MAXsupLoss.py")
    parser.add_argument("--output",  default=None,  help="Path to write scores JSON (optional)")
    args = parser.parse_args()

    results  = load_results(args.results)
    impl_src = load_impl_source(args.impl)

    # Grade each dimension
    d_score, d_notes = grade_design(results, impl_src)
    i_score, i_notes = grade_implementation(impl_src)
    e_score, e_notes = grade_execution(results)
    c_score, c_notes = grade_conclusion(results)

    # Weighted total
    total = (
        RUBRIC["D"] * d_score
        + RUBRIC["I"] * i_score
        + RUBRIC["E"] * e_score
        + RUBRIC["C"] * c_score
    )

    scores = {
        "D": round(d_score, 4),
        "I": round(i_score, 4),
        "E": round(e_score, 4),
        "C": round(c_score, 4),
        "total": round(total, 4),
    }

    # Pretty-print report
    print("\n" + "=" * 60)
    print("MaxSup CIFAR-10-LT Task — Grading Report")
    print("=" * 60)

    for dim, dim_notes in [("D", d_notes), ("I", i_notes), ("E", e_notes), ("C", c_notes)]:
        print(f"\n[{dim}] score = {scores[dim]:.2f} / 1.00  (weight {RUBRIC[dim]*100:.0f}%)")
        for note in dim_notes:
            print(f"    {note}")

    print(f"\n{'─'*60}")
    print(f"Weighted total: {scores['total']:.4f}")
    print(f"{'─'*60}\n")
    print(json.dumps(scores))

    if args.output:
        with open(args.output, "w") as f:
            json.dump(scores, f, indent=2)

    # Exit 0 if any partial credit, 1 if total zero
    sys.exit(0 if scores["total"] > 0 else 1)


if __name__ == "__main__":
    main()
