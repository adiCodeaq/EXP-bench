#!/bin/bash
set -euo pipefail

RESULTS_FILE="/workspace/results.json"
IMPL_FILE="/workspace/Maximum-Suppression-Regularization/LT/loss/MAXsupLoss.py"
GRADE_SCRIPT="/tests/grade.py"

mkdir -p /logs/verifier

echo "=== MaxSup Harbor Task Verifier ==="

python3 "$GRADE_SCRIPT" \
    --results "$RESULTS_FILE" \
    --impl "$IMPL_FILE" \
    --output /logs/verifier/reward.json

echo "=== Verifier complete ==="
