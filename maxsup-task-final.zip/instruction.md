# Research Task: Max Suppression Regularization for Long-Tailed Classification

## Research Question

Does Max Suppression Regularization (MaxSup) outperform Label Smoothing (LS) and Focal Loss
for image classification on a long-tailed (class-imbalanced) dataset?

Specifically: train ResNet-32 on CIFAR-10-LT with imbalance ratio 50 using three loss functions
— MaxSup, Label Smoothing, and Focal Loss — and compare their overall test accuracy.

## Background

**Label Smoothing (LS)** is widely used to reduce overconfidence in classifiers, but it has a
critical flaw: when a sample is misclassified (ground-truth logit `z_gt` is not the top logit),
LS penalizes `z_gt` and increases the gap between `z_gt` and the incorrect top-1 logit, amplifying
the error. This is the **error amplification** problem.

**Max Suppression (MaxSup)** fixes this by penalizing the top-1 logit `z_max` directly, regardless
of whether the prediction is correct. The MaxSup regularization loss is:

```
L_MaxSup = α * (z_max - mean(z))
```

where `z_max = max_k(z_k)` is the top-1 logit and `mean(z) = (1/K) * Σ z_k` is the mean logit
across all K classes. The total loss is:

```
L_total = CrossEntropy(logits, labels) + L_MaxSup
```

The regularization weight `α` uses a linearly increasing schedule from 0.1 to 0.2 over 200 epochs:

```
α = 0.1 + 0.1 * epoch / (total_epochs - 1)
```

However, note that the `set_epoch(epoch)` method on the loss must be called each training epoch
to update the schedule; if not called, α defaults to 0.1 (constant).

In the long-tailed setting, classes with fewer samples (low-shot classes) are harder to learn.
MaxSup's uniform regularization is expected to improve performance by avoiding the error
amplification that LS introduces for misclassified (often minority-class) samples.

## Expected Outcome

From the paper (Table 7), on CIFAR-10-LT with imbalance ratio 50, ResNet-32 backbone:

| Method     | Overall | Many  | Medium | Low |
|------------|---------|-------|--------|-----|
| Focal Loss | 76.8%   | 75.3% | 90.4%  | 0.0%|
| Label Smoothing | 80.5% | 81.1% | 75.4% | 0.0% |
| **MaxSup** | **81.4%** | 82.3% | 73.4% | 0.0% |

MaxSup achieves the highest overall accuracy, outperforming LS by ~0.9 percentage points.

## Repository Structure

The repository is at `/workspace/Maximum-Suppression-Regularization/`. The relevant subdirectory
for this experiment is `LT/`.

```
LT/
├── main.py                    # Entry point
├── run_networks.py            # Training and evaluation loop
├── config/CIFAR10_LT/
│   ├── causal_norm_32_maxsup_imb50.yaml   # MaxSup config (imbalance ratio 50)
│   ├── causal_norm_32_ls_imb50.yaml       # Label Smoothing config
│   └── causal_norm_32_focal_imb50.yaml    # Focal Loss config
├── loss/
│   ├── MAXsupLoss.py          # *** MASKED — you must implement this ***
│   ├── LSLoss.py              # Label Smoothing loss (reference)
│   └── FocalLoss.py           # Focal Loss (reference)
├── models/
│   └── ResNet32Feature.py     # ResNet-32 backbone
└── data/
    └── ImbalanceCIFAR.py      # Long-tailed CIFAR-10 data loader
```

## Step-by-Step Instructions

### Step 1: Implement `LT/loss/MAXsupLoss.py`

The file has been replaced with a stub. Implement the MaxSup loss based on the formula above.

Reference the `LSLoss.py` for the module structure. Your implementation must:
- Inherit from `nn.Module`
- Accept `(x, target)` in `forward()`, where `x` is the logits tensor `(batch_size, num_classes)`
  and `target` is the label tensor `(batch_size,)`
- Compute CE loss using `nn.CrossEntropyLoss` with no label smoothing
- Compute the MaxSup regularization: `α * mean(z_max - mean(z))`
  where `z_max = x.topk(1, dim=-1)[0]` (top-1 logit per sample)
- Return the sum of CE loss and MaxSup regularization
- Provide a `create_loss(num_epochs=200)` factory function (called with no args by the framework)

### Step 2: Run Training for All Three Methods

From the `LT/` directory, run:

```bash
cd /workspace/Maximum-Suppression-Regularization/LT

# MaxSup
python main.py --cfg ./config/CIFAR10_LT/causal_norm_32_maxsup_imb50.yaml

# Label Smoothing
python main.py --cfg ./config/CIFAR10_LT/causal_norm_32_ls_imb50.yaml

# Focal Loss
python main.py --cfg ./config/CIFAR10_LT/causal_norm_32_focal_imb50.yaml
```

Each run trains for 200 epochs and automatically evaluates on the test set at the end.

**Note on data**: CIFAR-10 will be automatically downloaded to `data/CIFAR10/` on first run.

### Step 3: Extract and Report Results

After training, extract the test accuracy for each method from the log files. The logs are at:
- `logs/CIFAR10_LT/models/resnet32_e200_warmup_causal_norm_ratio50_maxsup/log.txt`
- `logs/CIFAR10_LT/models/resnet32_e200_warmup_causal_norm_ratio50_ls/log.txt`
- `logs/CIFAR10_LT/models/resnet32_e200_warmup_causal_norm_ratio50_focal/log.txt`

Look for lines like:
```
Evaluation_accuracy_micro_top1: 0.814
Many_shot_accuracy_top1: 0.823
Median_shot_accuracy_top1: 0.734
Low_shot_accuracy_top1: 0.000
```

Note: overall = `Evaluation_accuracy_micro_top1`, many = `Many_shot_accuracy_top1`,
medium = `Median_shot_accuracy_top1`, low = `Low_shot_accuracy_top1`.

### Step 4: Save Results

Save your results to `/workspace/results.json` with this format:

```json
{
  "maxsup": {
    "overall": 81.4,
    "many": 82.3,
    "medium": 73.4,
    "low": 0.0
  },
  "ls": {
    "overall": 80.5,
    "many": 81.1,
    "medium": 75.4,
    "low": 0.0
  },
  "focal": {
    "overall": 76.8,
    "many": 75.3,
    "medium": 90.4,
    "low": 0.0
  },
  "conclusion": "Your one-sentence conclusion comparing MaxSup to LS and Focal Loss."
}
```

## Key Implementation Details

- The `CausalNormClassifier` applies additional causal normalization on the classifier head.
  You do **not** need to modify this — only implement `MAXsupLoss.py`.
- The loss framework calls `create_loss(*loss_args)` with no positional args (empty `loss_params`
  in the YAML), so `create_loss(num_epochs=200)` defaults work correctly.
- CIFAR data is loaded from `data/CIFAR10/` (relative to `LT/`); it will be auto-downloaded.
- Each training run takes ~25-40 minutes on a single GPU.
