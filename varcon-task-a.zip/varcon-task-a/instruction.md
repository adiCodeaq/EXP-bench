# Research Task: VarCon Confidence-Adaptive Temperature Scaling

## Research Question

Does VarCon's confidence-adaptive temperature scaling outperform fixed temperature
on CIFAR-100 KNN top-1 accuracy with a ResNet-50 encoder?

## Background

**VarCon** (Variational Supervised Contrastive Learning) reformulates supervised
contrastive learning as variational inference over latent class variables. It
maximizes a posterior-weighted ELBO that uses class-level centroids instead of
exhaustive pairwise comparisons.

A key innovation is its **confidence-adaptive temperature τ₂** (Equation 13):

```
τ₂ = (τ₁ − ε) + 2ε · p_θ(r | z)
```

where:
- `τ₁` = fixed base temperature (e.g., 0.1)
- `ε` = adaptation range (e.g., 0.02)
- `p_θ(r | z)` = model's posterior confidence on the true class

This adaptive mechanism:
- **Tightens constraints** for hard samples (low confidence → τ₂ ≈ τ₁ − ε → sharper target distribution)
- **Relaxes constraints** for easy/well-classified samples (high confidence → τ₂ ≈ τ₁ + ε → smoother target)

The VarCon loss is:

```
L_VarCon = D_KL(q_φ(r'|z) || p_θ(r'|z)) − log p_θ(r|z)
```

## Repository and File Structure

```
/workspace/
├── losses.py          ← EDIT THIS FILE (adaptive τ₂ is stubbed out)
├── run_experiment.py  ← Run this to evaluate; do NOT modify
├── util.py
└── networks/
    └── resnet_big.py
```

The file `/workspace/losses.py` contains the `VarConLoss` class.
Inside `VarConLoss.forward()`, the **confidence-adaptive temperature computation
has been removed and replaced with a stub** that raises `NotImplementedError`.

## Step-by-Step Instructions

### Step 1: Understand VarConLoss.forward() in losses.py

Open `/workspace/losses.py` and read the `forward()` method. The flow is:

1. Compute class centroids `w_r` from the batch features
2. Compute logits `z^T w_r / τ₁` and posterior `p_θ(r|z)` (Eq. 8)
3. Compute per-sample confidence: `confidences = p_θ(r|z)` for the true class
4. **STUB HERE**: Compute `τ₂` using the confidence-adaptive formula (Eq. 13)
5. Compute soft target distribution `q_φ` using `τ₂` (Eq. 10–12)
6. Compute `L_VarCon = KL(q_φ || p_θ) + NLL`

### Step 2: Implement the Confidence-Adaptive Temperature (Eq. 13)

Find the stub in `forward()` and replace it with:

```python
eps = self.epsilon
tau2 = (self.tau1 - eps) + 2.0 * eps * confidences  # [B]
tau2 = torch.clamp(tau2, min=1e-6)
```

Where:
- `self.tau1` is the fixed base temperature τ₁
- `self.epsilon` is the adaptation range ε
- `confidences` is `p_θ(r|z)` — the posterior probability assigned to the true class

### Step 3: Run the Experiment

```bash
cd /workspace
python run_experiment.py
```

The script trains two ResNet-50 models on CIFAR-100 (reduced epochs for
pipeline verification):
1. **VarCon** with adaptive temperature (τ₁=0.1, ε=0.02)
2. **Fixed-τ** baseline (τ₁=0.1, ε=0) — no adaptive mechanism

After training, it evaluates KNN top-1 accuracy (k=200) and saves results
to `/workspace/results.json`.

### Step 4: Check Results

The output `/workspace/results.json` should look like:

```json
{
  "varcon_acc": 0.2341,
  "fixed_acc": 0.2187,
  "delta_pp": 1.54,
  "varcon_outperforms_fixed": true,
  "paper_varcon_acc": 0.7829,
  "paper_fixed_acc": 0.7657,
  "n_epochs": 10,
  "dataset": "cifar100",
  "model": "resnet50",
  "knn_k": 200,
  "conclusion": "..."
}
```

## Expected Outcome

- **Paper result** (200 epochs): VarCon 78.29% vs SupCon 76.57% on CIFAR-100 (+1.72pp)
- **Pipeline run** (10 epochs): VarCon should outperform fixed-τ on KNN accuracy
- **Key insight**: the adaptive temperature tightens constraints on hard samples and
  relaxes them on easy ones, creating a better-organized embedding space

## Variable Classifications

- **Independent variable**: adaptive temperature (ε=0.02) vs fixed temperature (ε=0)
- **Dependent variable**: KNN top-1 accuracy on CIFAR-100
- **Constant variables**: dataset=CIFAR-100, model=ResNet-50, augmentation, batch size, LR
