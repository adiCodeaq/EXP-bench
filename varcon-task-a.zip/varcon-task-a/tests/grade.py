#!/usr/bin/env python3
"""
grade.py — Grader for VarCon Task 1A.

Research question: Does VarCon's confidence-adaptive temperature scaling
outperform fixed temperature on CIFAR-100 KNN top-1 accuracy?

Dimensions (EXP-Bench):
  D (25%) — Experimental design: correct IV/DV classification
  I (35%) — Implementation: τ₂ = (τ₁-ε) + 2ε·p_θ(r|z) correctly implemented
  E (20%) — Execution: experiment ran, produced valid numeric output
  C (20%) — Conclusion: VarCon (adaptive) outperforms fixed temperature
"""

import json
import os
import sys

# ── Weights ───────────────────────────────────────────────────────────────────
RUBRIC = {"D": 0.25, "I": 0.35, "E": 0.20, "C": 0.20}

RESULTS_PATH = "/workspace/results.json"
IMPL_PATH    = "/workspace/losses.py"

# Reasonable accuracy range for CIFAR-100 KNN after reduced training
ACC_MIN = 0.005   # even random init gives some structure
ACC_MAX = 0.99


def load_json(path):
    if not os.path.isfile(path):
        return None
    try:
        with open(path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def load_text(path):
    if not os.path.isfile(path):
        return None
    with open(path) as f:
        return f.read()


# ── D: Design ─────────────────────────────────────────────────────────────────
def grade_design(results, impl_src):
    """
    D1 (50%): results.json contains both varcon_acc and fixed_acc.
    D2 (50%): implementation shows adaptive vs fixed temperature structure.
    """
    score = 0.0
    notes = []

    # D1: results have correct IVs
    if results is not None:
        has_v = "varcon_acc" in results and isinstance(results["varcon_acc"], (int, float))
        has_f = "fixed_acc"  in results and isinstance(results["fixed_acc"],  (int, float))
        if has_v and has_f:
            score += 0.50
            notes.append("D1 PASS: results.json has varcon_acc and fixed_acc.")
        else:
            missing = [k for k, ok in [("varcon_acc", has_v), ("fixed_acc", has_f)] if not ok]
            notes.append(f"D1 FAIL: missing keys: {', '.join(missing)}.")
    else:
        notes.append("D1 FAIL: results.json not found or invalid.")

    # D2: code shows the adaptive temperature structure
    if impl_src is not None:
        c = impl_src
        has_tau1    = "self.tau1" in c or "tau1" in c
        has_epsilon = "self.epsilon" in c or "epsilon" in c
        has_conf    = "confidences" in c
        n_pass = sum([has_tau1, has_epsilon, has_conf])
        if n_pass >= 3:
            score += 0.50
            notes.append("D2 PASS: losses.py contains tau1, epsilon, confidences.")
        elif n_pass >= 2:
            score += 0.25
            notes.append(f"D2 PARTIAL: only {n_pass}/3 design signals found in losses.py.")
        else:
            notes.append("D2 FAIL: adaptive temperature design signals not found.")
    else:
        notes.append("D2 FAIL: losses.py not found.")

    return score, notes


# ── I: Implementation ─────────────────────────────────────────────────────────
def grade_implementation(impl_src):
    """
    I1 (30%): forward() no longer raises NotImplementedError for tau2.
    I2 (40%): τ₂ formula uses confidences (adaptive, not constant).
    I3 (30%): τ₂ formula matches Eq. 13 structure.
    """
    if impl_src is None:
        return 0.0, ["I: losses.py not found."]

    score = 0.0
    notes = []

    # Check for stub
    stub_active = (
        "raise NotImplementedError" in impl_src
        and "tau2" in impl_src.lower()
        and "Implement confidence" in impl_src
    )
    if stub_active:
        notes.append("I: τ₂ stub still active (NotImplementedError not removed).")
        return 0.0, notes

    # I1: forward defined and no NotImplementedError for tau2
    if "raise NotImplementedError" not in impl_src:
        score += 0.30
        notes.append("I1 PASS: forward() does not raise NotImplementedError.")
    else:
        score += 0.15
        notes.append("I1 PARTIAL: NotImplementedError present but may be elsewhere.")

    # I2: tau2 uses confidences (adaptive behavior)
    c = impl_src
    uses_conf = "confidences" in c and "tau2" in c
    if uses_conf:
        score += 0.40
        notes.append("I2 PASS: tau2 computation references 'confidences'.")
    else:
        notes.append("I2 FAIL: tau2 not found or does not use 'confidences'.")

    # I3: formula matches Eq. 13 structure
    # Look for: (tau1 - eps) + 2 * eps * confidences  or equivalent
    patterns = [
        "2.0 * eps * confidences",
        "2 * eps * confidences",
        "2.0*eps*confidences",
        "2*eps*confidences",
        "2.0 * self.epsilon * confidences",
        "2 * self.epsilon * confidences",
    ]
    has_formula = any(p in c for p in patterns)
    has_clamp = "clamp" in c and "tau2" in c
    if has_formula:
        score += 0.30
        notes.append("I3 PASS: Eq. 13 formula pattern found.")
    elif has_clamp and uses_conf:
        score += 0.15
        notes.append("I3 PARTIAL: tau2 uses confidences and is clamped, but exact formula unclear.")
    else:
        notes.append("I3 FAIL: Eq. 13 formula pattern not found.")

    return score, notes


# ── E: Execution ──────────────────────────────────────────────────────────────
def grade_execution(results):
    """
    E1 (50%): varcon_acc is a valid float in [ACC_MIN, ACC_MAX].
    E2 (50%): fixed_acc  is a valid float in [ACC_MIN, ACC_MAX].
    """
    if results is None:
        return 0.0, ["E: results.json not found — experiment did not complete."]

    score = 0.0
    notes = []

    for key, label, weight in [("varcon_acc", "E1", 0.50), ("fixed_acc", "E2", 0.50)]:
        val = results.get(key)
        if isinstance(val, (int, float)) and ACC_MIN <= val <= ACC_MAX:
            score += weight
            notes.append(f"{label} PASS: {key}={val:.4f} (in valid range).")
        elif isinstance(val, (int, float)):
            score += weight * 0.5
            notes.append(f"{label} PARTIAL: {key}={val:.4f} outside [{ACC_MIN}, {ACC_MAX}].")
        else:
            notes.append(f"{label} FAIL: {key} missing or non-numeric.")

    return score, notes


# ── C: Conclusion ─────────────────────────────────────────────────────────────
def grade_conclusion(results):
    """
    C1 (40%): varcon_acc > fixed_acc - 0.05 (directional; lenient 5pp tolerance).
    C2 (30%): varcon_outperforms_fixed flag is True.
    C3 (30%): conclusion text states VarCon / adaptive temperature outperforms.
    """
    if results is None:
        return 0.0, ["C: results.json not found."]

    score = 0.0
    notes = []

    va = results.get("varcon_acc")
    fa = results.get("fixed_acc")

    if not (isinstance(va, (int, float)) and isinstance(fa, (int, float))):
        notes.append("C: accuracy values missing or non-numeric — cannot evaluate.")
        return 0.0, notes

    # C1: directional claim (lenient: allow up to 5pp in wrong direction)
    delta = va - fa
    if delta > 0:
        score += 0.40
        notes.append(f"C1 PASS: varcon_acc ({va:.4f}) > fixed_acc ({fa:.4f}), Δ={delta*100:+.2f}pp.")
    elif delta > -0.05:
        score += 0.20
        notes.append(f"C1 PARTIAL: varcon_acc ({va:.4f}) within 5pp of fixed_acc ({fa:.4f}).")
    else:
        notes.append(f"C1 FAIL: varcon_acc ({va:.4f}) < fixed_acc ({fa:.4f}) by {abs(delta)*100:.2f}pp.")

    # C2: flag
    if results.get("varcon_outperforms_fixed") is True:
        score += 0.30
        notes.append("C2 PASS: varcon_outperforms_fixed = true.")
    else:
        notes.append(f"C2 FAIL: varcon_outperforms_fixed = {results.get('varcon_outperforms_fixed')}.")

    # C3: conclusion text references paper's claim
    text = results.get("conclusion", "")
    if isinstance(text, str) and len(text) > 20:
        tl = text.lower()
        has_varcon   = any(s in tl for s in ["varcon", "adaptive", "adaptive temperature"])
        has_positive = any(s in tl for s in ["outperform", "higher", "better",
                                              "78.29", "improves", "surpass",
                                              "confidence-adaptive"])
        has_negation = any(s in tl for s in ["does not outperform", "did not outperform",
                                              "not better", "underperforms"])
        if has_varcon and has_positive and not has_negation:
            score += 0.30
            notes.append("C3 PASS: conclusion mentions VarCon/adaptive and a positive outcome.")
        elif has_varcon or has_positive:
            score += 0.15
            notes.append("C3 PARTIAL: conclusion partially states the claim.")
        else:
            notes.append(f"C3 FAIL: conclusion does not state the claim: '{text[:120]}'")
    else:
        notes.append("C3 FAIL: conclusion field missing or too short.")

    return score, notes


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    results  = load_json(RESULTS_PATH)
    impl_src = load_text(IMPL_PATH)

    d_score, d_notes = grade_design(results, impl_src)
    i_score, i_notes = grade_implementation(impl_src)
    e_score, e_notes = grade_execution(results)
    c_score, c_notes = grade_conclusion(results)

    total = (
        RUBRIC["D"] * d_score
        + RUBRIC["I"] * i_score
        + RUBRIC["E"] * e_score
        + RUBRIC["C"] * c_score
    )

    scores = {
        "D":     round(d_score, 4),
        "I":     round(i_score, 4),
        "E":     round(e_score, 4),
        "C":     round(c_score, 4),
        "total": round(total,   4),
    }

    print("\n" + "=" * 60)
    print("VarCon Task 1A — Grading Report")
    print("=" * 60)
    for dim, dim_notes in [("D", d_notes), ("I", i_notes),
                            ("E", e_notes), ("C", c_notes)]:
        print(f"\n[{dim}] score = {scores[dim]:.2f} / 1.00  "
              f"(weight {RUBRIC[dim]*100:.0f}%)")
        for note in dim_notes:
            print(f"    {note}")

    print(f"\n{'─'*60}")
    print(f"Weighted total: {scores['total']:.4f}")
    print(f"{'─'*60}\n")
    print(json.dumps(scores))

    os.makedirs("/logs/verifier", exist_ok=True)
    with open("/logs/verifier/reward.json", "w") as f:
        json.dump({"reward": float(scores["total"])}, f)

    sys.exit(0 if scores["total"] > 0 else 1)


if __name__ == "__main__":
    main()
