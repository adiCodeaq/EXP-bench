#!/bin/bash
# Oracle solution for VarCon Task 1A.
# Replaces the masked losses.py with the complete implementation
# (confidence-adaptive τ₂, Eq. 13) and runs the experiment.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "=== Copying complete VarConLoss (with adaptive τ₂) ==="
cp "${SCRIPT_DIR}/losses_complete.py" /workspace/losses.py

# Limit training to 1 epoch and 500 samples so the oracle can finish on CPU
# (same approach as varcon-task-b / pir-task-b). We patch the *deployed* copy
# at /workspace/run_experiment.py at runtime — the repo task files are left
# untouched. The change is purely scale: N_EPOCHS 10→1 and the CIFAR-100 train
# set is capped to the first 500 windows via a torch Subset. The feature/KNN
# loaders (set in get_feat_loaders) and the loss math are left untouched, so
# the comparison and its numeric output stay meaningful.
echo "=== Patching run_experiment.py: 1 epoch, 500 training samples ==="
python - <<'PY'
p = "/workspace/run_experiment.py"
src = open(p).read()

e_old = "N_EPOCHS   = 10"
e_new = "N_EPOCHS   = 1 "
assert e_old in src, "N_EPOCHS config not found; run_experiment.py layout changed"

s_old = "    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True,"
s_new = (
    "    from torch.utils.data import Subset\n"
    "    dataset = Subset(dataset, range(min(len(dataset), 500)))\n"
    "    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True,"
)
assert s_old in src, "train DataLoader not found; run_experiment.py layout changed"

src = src.replace(e_old, e_new).replace(s_old, s_new)
open(p, "w").write(src)
print("Patched run_experiment.py: N_EPOCHS=1, train set capped to 500 samples")
PY

echo "=== Running VarCon Task 1A experiment ==="
python /workspace/run_experiment.py

echo "=== solve.sh complete. Results at /workspace/results.json ==="
